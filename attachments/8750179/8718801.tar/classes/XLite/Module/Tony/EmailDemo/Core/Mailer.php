<?php

namespace XLite\Module\Tony\EmailDemo\Core;

/**
 * Mailer
 */
abstract class Mailer extends \XLite\Core\Mailer implements \XLite\Base\IDecorator
{
    const TYPE_CUSTOM_EMAIL = 'customMail';

    /**
     * Send custom email
     *
     * @param string $to   Email address to send custom email to
     * @param string $body Custom email body text OPTIONAL
     * @param bool $advanced_mode Use yaml-loaded templates OPTIONAL
     *
     * @return string | null Possible error message
     */
    public static function sendEmailDemoMessage($to, $body = '', $advanced_mode = false)
    {
        static::register(
            array('custom_param' => $body)
        );

        $templatesDir = $advanced_mode ? 'modules/Tony/EmailDemo/message_advanced' : 'modules/Tony/EmailDemo/message';

        $result = static::compose(
            static::TYPE_CUSTOM_EMAIL,
            static::getSiteAdministratorMail(),
            $to,
            $templatesDir,
            array(),
            true,
            \XLite::ADMIN_INTERFACE
        );

        return static::getMailer()->getLastError();
    }
}
