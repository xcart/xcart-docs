<?php

namespace XLite\Module\Tony\EmailDemo\View\Form;

/**
 * Test email form
 */
class DemoEmail extends \XLite\View\Form\AForm
{
    /**
     * getDefaultTarget
     *
     * @return string
     */
    protected function getDefaultTarget()
    {
        return 'tony_custom_email';
    }

    /**
     * getDefaultAction
     *
     * @return string
     */
    protected function getDefaultAction()
    {
        return 'send_email';
    }
}
