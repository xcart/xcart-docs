<?php

namespace XLite\Module\Tony\EmailDemo\Controller\Admin;

class TonyCustomEmail extends \XLite\Controller\Admin\AAdmin
{
	/**
     * Flag to has email error
     *
     * @return string
     */
    public function hasTestEmailError()
    {
        return '' !== (string)\XLite\Core\Session::getInstance()->custom_email_error;
    }

    /**
     * Return error test email sending
     *
     * @return string
     */
    public function getTestEmailError()
    {
        $error = (string)\XLite\Core\Session::getInstance()->custom_email_error;

        \XLite\Core\Session::getInstance()->custom_email_error = '';

        return $error;
    }

    /**
     * Action to send test email notification
     *
     * @return void
     */
    protected function doActionSendEmail()
    {
        $request = \XLite\Core\Request::getInstance();

    	$error = \XLite\Core\Mailer::sendEmailDemoMessage(
            $request->custom_to_email_address,
            $request->custom_email_body,
            (bool) $request->custom_email_mode
        );

        if ($error) {
            \XLite\Core\Session::getInstance()->custom_email_error = $error;
            \XLite\Core\TopMessage::getInstance()->addError('Error of test e-mail sending: ' . $error);

        } else {
            \XLite\Core\TopMessage::getInstance()->add('Test e-mail have been successfully sent');
        }

        $this->setReturnURL(
            $this->buildURL('tony_custom_email', '', array())
        );
    }
}