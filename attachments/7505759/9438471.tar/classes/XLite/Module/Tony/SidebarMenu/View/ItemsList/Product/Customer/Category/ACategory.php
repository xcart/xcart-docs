<?php
namespace XLite\Module\Tony\SidebarMenu\View\ItemsList\Product\Customer\Category;

abstract class ACategory extends \XLite\View\ItemsList\Product\Customer\Category\ACategory implements \XLite\Base\IDecorator
{
    /**
    * Allowed sort criterions
    */
   const SORT_BY_MODE_NAME = 'translations.name';

    /**
     * Get products 'sort by' fields
     *
     * @return array
     */
    protected function getSortByFields()
    {
        $return = parent::getSortByFields();
        $return['default'] = static::SORT_BY_MODE_NAME;
        return $return;
    }
}
?>
