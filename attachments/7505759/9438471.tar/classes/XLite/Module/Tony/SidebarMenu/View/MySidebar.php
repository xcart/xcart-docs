<?php
 
namespace XLite\Module\Tony\SidebarMenu\View;
 
/**
 * @ListChild (list="sidebar.single", zone="customer", weight="100")
 * @ListChild (list="sidebar.first", zone="customer", weight="100")
 */
 
class MySidebar extends \XLite\View\SideBarBox
{
    protected function getHead()
    {
        return 'My Sidebar Menu';
    }
  
   
    protected function getDir()
    {
        return 'modules/Tony/SidebarMenu/menu';
    }
}
