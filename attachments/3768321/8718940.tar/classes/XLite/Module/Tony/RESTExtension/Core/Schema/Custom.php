<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * X-Cart
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the software license agreement
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.x-cart.com/license-agreement.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to licensing@x-cart.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not modify this file if you wish to upgrade X-Cart to newer versions
 * in the future. If you wish to customize X-Cart for your needs please
 * refer to http://www.x-cart.com/ for more information.
 *
 * @category  X-Cart 5
 * @author    Qualiteam software Ltd <info@x-cart.com>
 * @copyright Copyright (c) 2011-2015 Qualiteam software Ltd <info@x-cart.com>. All rights reserved
 * @license   http://www.x-cart.com/license-agreement.html X-Cart 5 License Agreement
 * @link      http://www.x-cart.com/
 */

namespace XLite\Module\Tony\RESTExtension\Core\Schema;

/**
 * Custom schema
 */
class Custom extends \XLite\Module\XC\RESTAPI\Core\Schema\Native
{
    /**
     * Schema code
     */
    const CODE = 'custom';

    /**
     * Check - schema is own this request or not
     *
     * @param string $schema Schema
     *
     * @return boolean
     */
    public static function isOwn($schema)
    {
        return !$schema || $schema == static::CODE;
    }

    /**
     * Convert model
     *
     * @param mixed   $model            Model OPTIONAL
     * @param boolean $withAssociations Convert with associations OPTIONAL
     *
     * @return mixed
     */
    protected function convertModel($model = null, $withAssociations = true)
    {
        $result = null;
        if ($model) {
            switch ($this->config->class) {
                case 'XLite\Model\Product':
                    $result = $this->convertModelProduct($model, $withAssociations);
                    break;

                default:
                    $result = parent::convertModel($model, $withAssociations);
            }
        }

        return $result;
    }

    /**
     * Convert model (product)
     * 
     * @param \XLite\Model\Product $model            Product
     * @param boolean              $withAssociations Convert with associations
     *  
     * @return array
     */
    protected function convertModelProduct(\XLite\Model\Product $model, $withAssociations)
    {
        $language = \XLite\Core\Config::getInstance()->General->default_language;
        $translation = $model->getSoftTranslation($language);

        $result = array(
            'sku'              => $model->getSku(),
            'productId'        => $model->getProductId(),
            'name'             => $translation->getName(),
            'description'      => $translation->getDescription(),
            'shortDescription' => $translation->getBriefDescription(),
            'price'            => $model->getPrice(),
            'weight'           => $model->getWeight(),
            'quantity'         => $model->getInventory()->getAmount(),
            'URL'              => $model->getFrontURL(),
            'enabled'          => $model->getEnabled(),
        );

        $categories = array();
        foreach ($model->getCategories() as $category) {
            $categories[] = $category->getStringPath();
        }

        if ($categories) {
            $result['categories'] = $categories;
        }

        $attributes = array();
        $repo = \XLite\Core\Database::getRepo('\XLite\Model\Attribute');
        $cnd = new \XLite\Core\CommonCell;
        $cnd->product = null;
        $cnd->productClass = null;

        foreach ($repo->search($cnd) as $a) {
            $attributes[$a->getName()] = $a->getAttributeValue($model, true);
        }

        if ($model->getProductClass()) {
            $cnd = new \XLite\Core\CommonCell;
            $cnd->product = null;
            $cnd->productClass = $model->getProductClass();

            foreach ($repo->search($cnd) as $a) {
                $attributes[$a->getName()] = $a->getAttributeValue($model, true);
            }
        }

        foreach ($model->getAttributes() as $a) {
            $attributes[$a->getName()] = $a->getAttributeValue($model, true);
        }

        if ($attributes) {
            $result['attributes'] = $attributes;
        }

        if (\Includes\Utils\ModulesManager::isActiveModule('XC\ProductVariants')) {
            if ($model->hasVariants()) {
                $result['variants'] = array();
                foreach ($model->getVariants() as $variant) {
                    $data = array(
                        'attributes' => array()
                    );
                    foreach ($variant->getValues() as $av) {
                        $data['attributes'][$av->getAttribute()->getName()] = $av->asString();
                    }
                    if ($variant->getSKU()) {
                        $data['sku'] = $variant->getSKU();
                    }
                    if (!$variant->getDefaultAmount()) {
                        $data['amount'] = $variant->getAmount();
                    }
                    if (!$variant->getDefaultPrice()) {
                        $data['price'] = $variant->getPrice();
                    }
                    if (!$variant->getDefaultWeight()) {
                        $data['weight'] = $variant->getWeight();
                    }
                    $result['variants'][$variant->getId()] = $data;
                }
            }
        }

        return $result;
    }
}
