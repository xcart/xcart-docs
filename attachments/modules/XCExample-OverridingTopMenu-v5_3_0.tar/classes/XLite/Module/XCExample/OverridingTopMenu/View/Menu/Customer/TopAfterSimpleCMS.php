<?php
 
namespace XLite\Module\XCExample\OverridingTopMenu\View\Menu\Customer;
 
/**
 * @Decorator\After ("CDev\SimpleCMS")
 */
 
class TopAfterSimpleCMS extends \XLite\View\Menu\Customer\Top implements \XLite\Base\IDecorator 
{
    protected function defineItems()
    {
        return $this->getMyItems();
    }
}