<?php
 
namespace XLite\Module\XCExample\OverridingTopMenu\View\Menu\Customer;
 
class Top extends \XLite\View\Menu\Customer\Top implements \XLite\Base\IDecorator 
{
    protected function getMyItems()
    {
        $return = array();
 
        $return[] = array (
            'url' => 'http://google.com',
            'label' => 'Google menu',
            'controller' => false,
            );
 
        return $return;
    }
 
    protected function defineItems()
    {
        parent::defineItems();
        return $this->getMyItems();
    }
}