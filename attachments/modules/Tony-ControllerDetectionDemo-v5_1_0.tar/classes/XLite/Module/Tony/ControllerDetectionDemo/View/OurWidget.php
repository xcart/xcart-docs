<?php

namespace XLite\Module\Tony\ControllerDetectionDemo\View;

/**
 * @ListChild (list="body", weight="1", zone="customer")
 */

class OurWidget extends \XLite\View\AView
{
	public function getDefaultTemplate() 
	{
		return 'modules/Tony/ControllerDetectionDemo/text.tpl';
	}

	public static function getAllowedTargets() 
	{
		$list = parent::getAllowedTargets();

		$list[] = 'checkout'; // checkout page
		$list[] = 'main'; // home page
		$list[] = 'category'; // category page

		return $list;
	}

	public function getOurText()
	{
		$return = 'no text';

		if (\XLite::getController() instanceof \XLite\Controller\Customer\Checkout) {
			$return = 'This is checkout page';
		} elseif (\XLite::getController() instanceof \XLite\Controller\Customer\Main) {
			$return = 'This is home page';
		} elseif (\XLite::getController() instanceof \XLite\Controller\Customer\Category) {
			$return = 'This is a category page';
		}

		return $return;
	}
}