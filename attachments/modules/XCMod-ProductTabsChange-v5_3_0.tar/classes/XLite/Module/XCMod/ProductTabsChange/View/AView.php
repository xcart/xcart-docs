<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCMod\ProductTabsChange\View;

/**
 * Abstract widget
 */
abstract class AView extends \XLite\View\AView implements \XLite\Base\IDecorator
{
    public function getCSSFiles()
    {
        return array_merge(
            parent::getCSSFiles(),
            array(
                'modules/XCMod/ProductTabsChange/css/style.css',
            )
        );
    }    
}