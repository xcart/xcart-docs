<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ImportExportDemo\View\Export;

/**
 * Begin section
 */
abstract class Begin extends \XLite\View\Export\Begin implements \XLite\Base\IDecorator
{
    protected function getSections()
    {
        $return = parent::getSections();
        $return['XLite\Module\XCExample\ImportExportDemo\Logic\Export\Step\ImportEntities'] = 'Our import entitites';

        return $return;
    }
}
