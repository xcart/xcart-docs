<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ImportExportDemo\Logic\Export;

/**
 * Generator
 */
abstract class Generator extends \XLite\Logic\Export\Generator implements \XLite\Base\IDecorator
{
    protected function defineSteps()
    {
        $return = parent::defineSteps();
        $return[] = 'XLite\Module\XCExample\ImportExportDemo\Logic\Export\Step\ImportEntities';
        
        return $return;
    }
}
