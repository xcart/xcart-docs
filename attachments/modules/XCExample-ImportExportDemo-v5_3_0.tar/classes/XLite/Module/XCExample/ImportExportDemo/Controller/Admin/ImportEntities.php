<?php
 
namespace XLite\Module\XCExample\ImportExportDemo\Controller\Admin;
 
class ImportEntities extends \XLite\Controller\Admin\AAdmin
{
}