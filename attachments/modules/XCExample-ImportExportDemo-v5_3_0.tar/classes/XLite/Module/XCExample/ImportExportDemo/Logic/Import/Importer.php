<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ImportExportDemo\Logic\Import;

/**
 * Importer
 */
abstract class Importer extends \XLite\Logic\Import\Importer implements \XLite\Base\IDecorator
{
    public static function getProcessorList()
    {
        return array_merge(
            parent::getProcessorList(),
            array(
                'XLite\Module\XCExample\ImportExportDemo\Logic\Import\Processor\ImportEntities',
            )
        );
    }
}
