<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ImportExportDemo\Logic\Import\Processor;

/**
 * Reviews import processor
 */
class ImportEntities extends \XLite\Logic\Import\Processor\AProcessor
{
    public static function getTitle()
    {
        return static::t('Our import entities are imported');
    }

    protected function getRepository()
    {
        return \XLite\Core\Database::getRepo('XLite\Module\XCExample\ImportExportDemo\Model\ImportEntity');
    }

    protected function defineColumns()
    {
        return array(
            'id'        => array(
                static::COLUMN_IS_KEY   => true,
            ),
            'body'      => array(),
            'enabled'   => array(),
        );
    }

    public function getFileNameFormat()
    {
        return 'import-entities.csv';
    }

    protected function isImportedFile(\SplFileInfo $file)
    {
        return 0 === strpos($file->getFilename(), 'import-entities');
    }

    public static function getMessages()
    {
        return parent::getMessages() +
            array(
                'IMPORT-DEMO-BODY-IS-EMPTY' => 'Text of import entity is empty.',
            );
    }

    protected function verifyBody($value, array $column)
    {
        if ($this->verifyValueAsEmpty($value)) {
            $this->addError('IMPORT-DEMO-BODY-IS-EMPTY', array('column' => $column, 'value' => $value));
        }
    }

    protected function normalizeEnabledValue($value)
    {
        return $this->normalizeValueAsBoolean($value);
    }

    protected function importIdColumn(\XLite\Module\XCExample\ImportExportDemo\Model\ImportEntity $model, $value, array $column)
    {
    }
}