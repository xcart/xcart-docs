<?php

namespace XLite\Module\XCExample\ImportExportDemo\Logic\Export\Step;

class ImportEntities extends \XLite\Logic\Export\Step\AStep
{
    protected function getRepository()
    {
        return \XLite\Core\Database::getRepo('XLite\Module\XCExample\ImportExportDemo\Model\ImportEntity');
    }

    protected function defineColumns()
    {
        $columns = array(
            'id'        => array(),
            'body'      => array(),
            'enabled'   => array(),
        );

        return $columns;
    }

    protected function getFilename()
    {
        return 'import-entities.csv';
    }

    protected function getIdColumnValue(array $dataset, $name, $i)
    {
        return $this->getColumnValueByName($dataset['model'], 'id');
    }

    protected function getBodyColumnValue(array $dataset, $name, $i)
    {
        return $this->getColumnValueByName($dataset['model'], 'body');
    }

    protected function getEnabledColumnValue(array $dataset, $name, $i)
    {
        return $this->getColumnValueByName($dataset['model'], 'enabled');
    }    
}