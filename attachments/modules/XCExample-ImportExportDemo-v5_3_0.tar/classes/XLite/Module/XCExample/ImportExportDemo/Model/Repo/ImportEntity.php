<?php
 
namespace XLite\Module\XCExample\ImportExportDemo\Model\Repo;
 
class ImportEntity extends \XLite\Model\Repo\ARepo
{
    protected $defaultOrderBy = 'id';
}