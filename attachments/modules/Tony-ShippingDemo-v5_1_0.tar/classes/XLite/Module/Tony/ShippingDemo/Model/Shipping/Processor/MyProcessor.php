<?php

namespace XLite\Module\Tony\ShippingDemo\Model\Shipping\Processor;

class MyProcessor extends \XLite\Model\Shipping\Processor\AProcessor
{
	protected $processorId = 'myprocessor';

	public function getProcessorName() 
	{
		return 'My Processor';
	}

	public function getRates($inputData, $ignoreCache = false)
	{
		$rates = array();

		$rate = new \XLite\Model\Shipping\Rate();
		$rate->setMethod($this->getShippingMethod());
		$rate->setBaseRate(10.00);

		$rates[] = $rate;

		return $rates;
	}

	protected function getShippingMethod() 
	{
		return \XLite\Core\Database::getRepo('\XLite\Model\Shipping\Method')->findOneByProcessor($this->getProcessorId());
	}
}