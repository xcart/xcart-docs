<?php

namespace XLite\Module\Tony\EmailFix\Core;

class Mailer extends \XLite\Core\Mailer implements \XLite\Base\IDecorator
{
	public static function sendChangedOrder(\XLite\Model\Order $order) {
		// nothing to do here
	}
}