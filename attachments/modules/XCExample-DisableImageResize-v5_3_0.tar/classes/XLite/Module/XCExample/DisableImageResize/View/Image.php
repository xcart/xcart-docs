<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\DisableImageResize\View;

/**
 * Image
 */
class Image extends \XLite\View\Image implements \XLite\Base\IDecorator
{
	protected function defineWidgetParams()
    {
		parent::defineWidgetParams();

		$this->widgetParams[self::PARAM_USE_CACHE] = new \XLite\Model\WidgetParam\TypeBool('Use cache', 0);
	}
}