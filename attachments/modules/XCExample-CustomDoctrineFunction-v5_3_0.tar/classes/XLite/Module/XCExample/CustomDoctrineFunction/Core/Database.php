<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\CustomDoctrineFunction\Core;

/**
 * Database
 */
abstract class Database extends \XLite\Core\Database implements \XLite\Base\IDecorator
{
    public function connect()
    {
        parent::connect();

        $this->configuration->addCustomStringFunction(
            'rand', 
            '\\XLite\\Module\\XCExample\\CustomDoctrineFunction\\Core\\Doctrine\\RandFunction'
        );

        $this->configuration->addCustomStringFunction(
            'round', 
            '\\XLite\\Module\\XCExample\\CustomDoctrineFunction\\Core\\Doctrine\\RoundFunction'
        );

    }
}