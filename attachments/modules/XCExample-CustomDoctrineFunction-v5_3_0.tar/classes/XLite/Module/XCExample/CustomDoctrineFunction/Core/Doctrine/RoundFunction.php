<?php

namespace XLite\Module\XCExample\CustomDoctrineFunction\Core\Doctrine;

use Doctrine\ORM\Query\Lexer;
use Doctrine\ORM\Query\Parser;
use Doctrine\ORM\Query\SqlWalker;

/**
 * ROUND (3.1415, 2) = 3.14
 */

class RoundFunction extends \Doctrine\ORM\Query\AST\Functions\FunctionNode
{
    public function parse(Parser $parser)
    {
        $parser->match(Lexer::T_IDENTIFIER);

        $parser->match(Lexer::T_OPEN_PARENTHESIS);

        $this->value = $parser->ArithmeticPrimary();

        $parser->match(Lexer::T_COMMA);

        $this->precision = $parser->ArithmeticPrimary();        

        $parser->match(Lexer::T_CLOSE_PARENTHESIS);
    }

    /**
     * Get SQL query part
     * 
     * @param \Doctrine\ORM\Query\SqlWalker $sqlWalker SQL walker
     *  
     * @return string
     */
    public function getSql(SqlWalker $sqlWalker)
    {
        return 'ROUND(' .
            $this->value->dispatch($sqlWalker) . ', ' .
            $this->precision->dispatch($sqlWalker) .
            ')';
    }
}