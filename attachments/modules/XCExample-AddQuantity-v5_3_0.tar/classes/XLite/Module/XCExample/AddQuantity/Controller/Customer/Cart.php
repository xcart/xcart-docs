<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\AddQuantity\Controller\Customer;

/**
 * \XLite\Controller\Customer\Cart
 */
abstract class Cart extends \XLite\Controller\Customer\Cart implements \XLite\Base\IDecorator
{
    public function addItem($item)
    {
        if (0 == $item->getAmount() % 2) {
            $result = parent::addItem($item);
        } else {
            $result = false;
            \XLite\Core\TopMessage::addWarning('You can add only even number of this product (2, 4, 6, etc).');
        }

        return $result;
    }
}
