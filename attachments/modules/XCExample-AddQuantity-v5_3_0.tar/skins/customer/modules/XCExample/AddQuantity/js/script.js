/* vim: set ts=2 sw=2 sts=2 et: */

/**
 * Js
 *
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

$(".product-buttons .add2cart").click(
    function() 
    {
        if (parseInt($(".product-buttons input.quantity").val()) % 2 != 0) {
            alert('You can add only even number of this product (2, 4, 6, etc).');
            event.preventDefault();
        }
    }
)