<?php

namespace XLite\Module\XCExample\NewEntityDemo\Model\Repo;

class QuickMessage extends \XLite\Model\Repo\ARepo
{  
    public function findNewest()
    {
        return $this->createQueryBuilder('qm')
            ->andWhere('qm.enabled = 1')
            ->addOrderBy('qm.id', 'DESC')
            ->setFirstResult(0)
            ->setMaxResults(3)
            ->getResult();
    }    
}