<?php

namespace XLite\Module\XCExample\NewEntityDemo\View;

/**
 * @ListChild (list="sidebar.first", zone="customer", weight="10")
 */

class QuickMessageMenu extends \XLite\View\SideBarBox
{
    protected function getHead()
    {
        return 'Store quick messages';
    }

    protected function getDir()
    {
        return 'modules/XCExample/NewEntityDemo/quickmessage';
    }

    protected function getMessages()
    {
        $return = \XLite\Core\Database::getRepo('\XLite\Module\XCExample\NewEntityDemo\Model\QuickMessage')->findNewest();

        return $return;
    }
}