<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\NewEntityDemo\View\Page\Admin;

/**
 * QuickMessagesPage
 *
 * @ListChild (list="admin.center", zone="admin")
 */
class QuickMessagesPage extends \XLite\View\AView
{     
    /**
     * Return list of allowed targets
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('quick_messages'));
    }
      
    /**
     * Return widget default template
     */
    public function getDefaultTemplate()
    {
        return 'modules/XCExample/NewEntityDemo/page/quick_messages/body.twig';
    }
}