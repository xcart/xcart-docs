<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\Discount\Logic\Order\Modifier;

class Discount extends \XLite\Logic\Order\Modifier\Discount
{
    const MODIFIER_CODE = 'DISCOUNT';

    protected $type = \XLite\Model\Base\Surcharge::TYPE_DISCOUNT;

    protected $code = self::MODIFIER_CODE;

    public function calculate()
    {
        $surcharge = null;

        $discount = $this->getOrder()->getSubtotal() * 0.1;

        $surcharge = $this->addOrderSurcharge($this->code, $discount * -1);
        $this->distributeDiscount($discount);

        return $surcharge;
    }
}