<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ModelEditingDemo\View\Page\Admin;

/**
 * Product edit page view
 *
 * @ListChild (list="admin.center", zone="admin")
 */
class ModelEditingDemo extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('model_editing_demo'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/ModelEditingDemo/page/model_editing_demo/body.twig';
    }
}