<?php

namespace XLite\Module\XCExample\ModelEditingDemo\View\Form\Model;

class Product extends \XLite\View\Form\AForm
{
    protected function getDefaultTarget()
    {
        return 'model_editing_demo';
    }
  
    protected function getDefaultAction()
    {
        return 'update';
    }

    protected function getDefaultParams()
    {
        return array(
            'product_id' => \XLite\Core\Request::getInstance()->product_id,
        );
    }    
}