<?php

namespace XLite\Module\XCExample\AttributesDemo\View;

/**
 * @ListChild (list="product.details.page.info", weight="30", zone="customer")
 */

class AttributesDemo extends \XLite\View\AView
{
    protected function getDefaultTemplate()
    {
        return 'modules\XCExample\AttributesDemo\attributes_demo\body.twig';
    }

    protected function getAttributeInfo()
    {        
        foreach ($this->getProduct()->getAttributes() as $attribute) {

            // to see more info about attribute object, look into \XLite\Model\Attribute class
            // classes/XLite/Model/Attribute.php

            $result = array (
                'name'      => $attribute->getName(),
                'type'      => $attribute->getType(),
                'values'    => array(),
            );

            foreach ($attribute->getAttributeValues() as $attributeValue) {
                if (
                    in_array(
                        $attribute->getType(), 
                        array(
                            \XLite\Model\Attribute::TYPE_CHECKBOX,
                            \XLite\Model\Attribute::TYPE_TEXT
                        )
                    )
                ) {
                    $result['values'][] = $attributeValue->getValue();

                    // more info about attribute value objects in \XLite\Model\AttributeValue\AttributeValueCheckbox
                    // and \XLite\Model\AttributeValue\AttributeValueText classes

                } elseif ($attribute->getType() == \XLite\Model\Attribute::TYPE_SELECT) {

                    $result['values'][] = $attributeValue->asString();

                }

            }

            $return[] = $result;

        }

        return $return;
    }

    public function getAttributeTypeByCode($code)
    {
        return \XLite\Model\Attribute::getTypes($code);
    }
}