<?php

namespace XLite\Module\Tony\HomePageWithoutSidebar\View;

class Content extends \XLite\View\Content implements \XLite\Base\IDecorator
{
	protected function isSidebarFirstVisible()
	{
		if ('main' == $this->getTarget()) {
			$return = false;
		} else {
			$return = parent::isSidebarFirstVisible();
		}

		return $return;
	}
}