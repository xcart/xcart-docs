<?php

namespace XLite\Module\Tony\HomePageWithoutSidebar\View;

class Category extends \XLite\View\Category implements \XLite\Base\IDecorator
{
	public static function isSidebarFirstVisible()
	{
		\XLite\Logger::logCustom('feakie', $this->getCategory()->getId(), true);

		return parent::isSidebarFirstVisible();
	}
}