<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ImageDemo\View\Model;

/**
 * Product view model
 */
abstract class Product extends \XLite\View\Model\Product implements \XLite\Base\IDecorator
{
	public function __construct(array $params = array(), array $sections = array())
	{
		parent::__construct($params, $sections);

		$this->schemaDefault['secondaryImages'] = array(
            self::SCHEMA_CLASS    => '\XLite\View\FormField\FileUploader\Image',
            self::SCHEMA_LABEL    => 'Secondary images',
            self::SCHEMA_REQUIRED => false,
            \XLite\View\FormField\FileUploader\Image::PARAM_MULTIPLE => true,
        );
	}
}
