<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ImageDemo\Model\Repo\Image\Product;

class SecondaryImage extends \XLite\Model\Repo\Base\Image
{
    protected $defaultOrderBy = 'orderby';

    /**
     * Returns the name of the directory within 'root/images' where images stored
     */
    public function getStorageName()
    {
        return 'product_secondary';
    }

}
