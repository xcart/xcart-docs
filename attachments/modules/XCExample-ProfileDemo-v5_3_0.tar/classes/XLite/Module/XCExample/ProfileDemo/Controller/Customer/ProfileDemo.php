<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ProfileDemo\Controller\Customer;

/**
 * Profile demo controller
 */
class ProfileDemo extends \XLite\Controller\Customer\ACustomer
{
	public function isAnonymous()
	{
		$profile = \XLite\Core\Auth::getInstance()->getProfile();

		return $profile ? $profile->getAnonymous() : true;
	}

	public function getProfile()
	{
		return \XLite\Core\Auth::getInstance()->getProfile();
	}
}