<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\FooterDemo\View;

abstract class AView extends \XLite\View\AView implements \XLite\Base\IDecorator
{
	public function getCSSFiles()
    {
        $list = parent::getCSSFiles();

        $list[] = 'modules/Tony/FooterDemo/css/style.css';

        return $list;
    }
}
