<?php

namespace XLite\Module\XCExample\SettingsDemo\View;

/**
 * @ListChild (list="head")
 */
 
class Header extends \XLite\View\AView
{
	protected function getDefaultTemplate() 
	{
		return 'modules/XCExample/SettingsDemo/html_code.twig';
	}

	public function getHtmlCode()
	{
		return \XLite\Core\Config::getInstance()->XCExample->SettingsDemo->html_code;
	}
}