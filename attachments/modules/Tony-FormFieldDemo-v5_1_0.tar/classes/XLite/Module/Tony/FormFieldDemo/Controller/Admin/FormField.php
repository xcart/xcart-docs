<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\FormFieldDemo\Controller\Admin;

/**
 * Form field controller
 */
class FormField extends \XLite\Controller\Admin\AAdmin
{
}