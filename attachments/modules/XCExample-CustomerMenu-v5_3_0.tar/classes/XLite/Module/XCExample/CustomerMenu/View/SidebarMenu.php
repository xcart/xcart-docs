<?php

namespace XLite\Module\XCExample\CustomerMenu\View;

/**
 * @ListChild (list="sidebar.single", zone="customer", weight="500")
 * @ListChild (list="sidebar.first", zone="customer", weight="500")
 */

class SidebarMenu extends \XLite\View\SideBarBox
{
    protected function getHead()
    {
        return 'Our custom menu';
    }

    protected function getDir()
    {
        return 'modules/XCExample/CustomerMenu/menu';
    }
}