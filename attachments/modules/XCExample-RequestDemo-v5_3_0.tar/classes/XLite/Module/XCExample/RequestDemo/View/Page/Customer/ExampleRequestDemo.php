<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\RequestDemo\View\Page\Customer;

/**
 * @ListChild (list="center")
 */
class ExampleRequestDemo extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('example_request_demo'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/RequestDemo/page/example-request-demo/body.twig';
    }

    public function getParamValue()
    {
        return \XLite\Core\Request::getInstance()->param;
    }

    public function getParam2Value()
    {
        $return = '';

        if (isset($_GET['param2'])) {
            $return = $_GET['param2'];
        }

        return $return;
    }
}