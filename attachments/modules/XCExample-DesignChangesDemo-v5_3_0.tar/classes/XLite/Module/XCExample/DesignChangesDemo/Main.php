<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\DesignChangesDemo;

/**
 * Main module
 */
abstract class Main extends \XLite\Module\AModule
{
    /**
     * Author name
     *
     * @return string
     */
    public static function getAuthorName()
    {
        return 'XCExample';
    }

    /**
     * Module name
     *
     * @return string
     */
    public static function getModuleName()
    {
        return 'Design changes demo';
    }

    /**
     * Module description
     *
     * @return string
     */
    public static function getDescription()
    {
        return '';
    }

    /**
     * Get module major version
     *
     * @return string
     */
    public static function getMajorVersion()
    {
        return '5.3';
    }

    /**
     * Module version
     *
     * @return string
     */
    public static function getMinorVersion()
    {
        return '0';
    }

    protected static function moveTemplatesInLists()
    {
        $templates = [
            'layout/header/header.logo.twig' => [
                static::TO_DELETE  => [
                    ['layout.header', \XLite\Model\ViewList::INTERFACE_CUSTOMER],
                ],
            ],
        ];

        return $templates;
    }    

/*
    protected static function moveClassesInLists()
    {
        $classes = [
            'XLite\Module\XCExample\DesignChangesDemo\View\HeaderLogo' => [
                static::TO_DELETE => [
                    ['layout.header', 'customer'],
                ],
            ],
        ];

        return $classes;
    }
*/
}