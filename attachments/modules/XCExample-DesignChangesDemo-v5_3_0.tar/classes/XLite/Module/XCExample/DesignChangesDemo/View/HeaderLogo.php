<?php

namespace XLite\Module\XCExample\DesignChangesDemo\View;

/**
 * @ListChild (list="layout.header", zone="customer", weight="101")
 */

class HeaderLogo extends \XLite\View\AView
{
    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/DesignChangesDemo/date_label.twig';
    }

    protected function getTime()
    {
        return date('H:i');
    }
}