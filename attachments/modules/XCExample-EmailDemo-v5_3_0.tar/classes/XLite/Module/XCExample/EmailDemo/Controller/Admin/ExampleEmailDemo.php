<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\EmailDemo\Controller\Admin;

/**
 * ExampleEmailDemo
 */
class ExampleEmailDemo extends \XLite\Controller\Admin\AAdmin
{
    protected function doActionSend()
    {
        $request = \XLite\Core\Request::getInstance();

        $error = \XLite\Core\Mailer::sendEmailDemoMessage(
            $request->to,
            $request->body
        );

        if (!is_null($error)) {
            \XLite\Core\TopMessage::getInstance()->addError('Error of test e-mail sending: ' . $error);
        } else {
            \XLite\Core\TopMessage::getInstance()->add('Test e-mail has been successfully sent');
        }

        $this->setReturnURL(
            $this->buildURL('example_email_demo', '', array())
        );
    }
}