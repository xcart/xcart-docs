<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\EmailDemo\Core;

/**
 * Mailer core class
 */
abstract class Mailer extends \XLite\Core\Mailer implements \XLite\Base\IDecorator
{
    public static function sendEmailDemoMessage($to, $body = '')
    {
        static::register([
            'body' => $body, 
            'subject' => 'Demo notification'
        ]);

        $templatesDir = 'modules/XCExample/EmailDemo/message';

        static::compose(
            'DemoMail',
            static::getSiteAdministratorMail(),
            $to,
            $templatesDir,
            array(),
            true,
            \XLite::CUSTOMER_INTERFACE
        );

        return static::getMailer()->getLastError();
    }
}
