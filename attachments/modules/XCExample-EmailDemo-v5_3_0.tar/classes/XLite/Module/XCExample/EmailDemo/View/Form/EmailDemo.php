<?php

namespace XLite\Module\XCExample\EmailDemo\View\Form;

class EmailDemo extends \XLite\View\Form\AForm
{
    protected function getDefaultTarget()
    {
        return 'example_email_demo';
    }

    protected function getDefaultAction()
    {
        return 'send';
    }
}