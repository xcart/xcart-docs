<?php

namespace XLite\Module\XCExample\EmailDemo\View\Model;

class EmailDemo extends \XLite\View\Model\AModel
{
    protected $schemaDefault = [
        'to' => [
            self::SCHEMA_CLASS      => 'XLite\View\FormField\Input\Text\Email',
            self::SCHEMA_LABEL      => 'Email to',
            self::SCHEMA_REQUIRED   => true,
        ],    
        'body' => [
            self::SCHEMA_CLASS      => 'XLite\View\FormField\Input\Text',
            self::SCHEMA_LABEL      => 'Body',
            self::SCHEMA_REQUIRED   => false,            
        ],
    ];

    protected function getDefaultModelObject()
    {
        return null;
    }

    protected function getFormClass()
    {
        return 'XLite\Module\XCExample\EmailDemo\View\Form\EmailDemo';
    }
}