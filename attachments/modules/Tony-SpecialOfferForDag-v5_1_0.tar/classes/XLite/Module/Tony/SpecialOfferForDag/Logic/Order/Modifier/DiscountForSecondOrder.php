<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\SpecialOfferForDag\Logic\Order\Modifier;

class DiscountForSecondOrder extends \XLite\Logic\Order\Modifier\Discount
{
    /**
     * Modifier code is the same as a base Discount - this will be aggregated to the single 'Discount' line in cart totals
     */
    const MODIFIER_CODE = 'DISCOUNT';


    /**
     * Modifier type (see \XLite\Model\Base\Surcharge)
     *
     * @var   string
     */
    protected $type = \XLite\Model\Base\Surcharge::TYPE_DISCOUNT;

    /**
     * Modifier unique code
     *
     * @var   string
     */
    protected $code = self::MODIFIER_CODE;

    public function canApply()
    {
        return parent::canApply()
            && $this->hasDiscount();
    }

    protected function hasDiscount()
    {
        $profile = \XLite\Core\Auth::getInstance()->getProfile();

        if ($profile) {
            $cnd = new \XLite\Core\CommonCell();
            $cnd->profile = $profile;

            $orders = \XLite\Core\Database::getRepo('XLite\Model\Order')->search($cnd);
        }

        return !empty($orders);
    }

    public function calculate()
    {
        $surcharge = null;

        $surcharge = $this->getOrder()->getSubtotal() / 10;

        $this->addOrderSurcharge($this->code, $surcharge * -1);
        $this->distributeDiscount($surcharge);

        return $surcharge;
    }
}