<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\SpecialOfferForDag\Logic\Order\Modifier;

class Discount extends \XLite\Logic\Order\Modifier\Discount
{
    /**
     * Modifier code is the same as a base Discount - this will be aggregated to the single 'Discount' line in cart totals
     */
    const MODIFIER_CODE = 'DISCOUNT';


    /**
     * Modifier type (see \XLite\Model\Base\Surcharge)
     *
     * @var   string
     */
    protected $type = \XLite\Model\Base\Surcharge::TYPE_DISCOUNT;

    /**
     * Modifier unique code
     *
     * @var   string
     */
    protected $code = self::MODIFIER_CODE;

    public function canApply()
    {
        return parent::canApply();
    }

    public function calculate()
    {
        $surcharge = 0;

        $categoryNumbers = array();

        foreach ($this->getOrderItems() as $item) {

            foreach ($item->getProduct()->getCategories() as $category) {

                $categoryId = $category->getCategoryId();

                if (!isset($categoryNumbers[$categoryId])) {
                    $categoryNumbers[$categoryId]['quantity'] = $item->getAmount();
                    $categoryNumbers[$categoryId]['products'] = array($item);
                } else {
                    $categoryNumbers[$categoryId]['quantity'] += $item->getAmount();
                    $categoryNumbers[$categoryId]['products'] = array_merge($categoryNumbers[$categoryId]['products'], array($item));
                }
            }
        }

        foreach ($categoryNumbers as $categoryId => $value) {
            if ($value['quantity'] >= 3) {
                $freeProductsPerCategory = floor($value['quantity'] / 3);
                $surcharge += $this->searchCheapestProductsSurcharge($value['products'], $freeProductsPerCategory);
            }
        }

        if ($surcharge <= 0) {
            $surcharge = null;
        }  else {
            $surcharge = $this->addOrderSurcharge($this->code, $surcharge * -1);
        }

        return $surcharge;
    }

    protected function searchCheapestProductsSurcharge($items, $freeProductsNumber = 1)
    {
        $freeProductsNumber = intval($freeProductsNumber);
        $surcharge = 0;

        usort($items, array(__CLASS__, 'sortItemsByPrice'));

        reset($items);

        while ($freeProductsNumber > 0) {
            list( , $item) = each($items);

            if ($item->getAmount() > $freeProductsNumber) {
                $surcharge += $item->getItemPrice() * $freeProductsNumber;
                $freeProductsNumber = 0;
            } elseif ($item->getAmount() <= $freeProductsNumber) {
                $surcharge += $item->getItemPrice() * $item->getAmount();
                $freeProductsNumber -= $item->getAmount();
            }
        }

        return $surcharge;
    }

    protected static function sortItemsByPrice($a, $b) 
    {
        if ($a->getItemPrice() == $b->getItemPrice())
            return 0;

        return ($a->getItemPrice() > $b->getItemPrice()) ? +1 : -1;
    }

    public function getSurchargeInfo(\XLite\Model\Base\Surcharge $surcharge)
    {
        $info = new \XLite\DataSet\Transport\Order\Surcharge;

        $info->name = \XLite\Core\Translation::lbl('Discount');

        return $info;
    }
}