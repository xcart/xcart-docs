<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ProductOrderPropertyDemo\Model;

/**
 * Something customer can put into his cart
 */
abstract class OrderItem extends \XLite\Model\OrderItem implements \XLite\Base\IDecorator
{
    /**
     * @Column (type="string", length=32)
     */
    protected $testField;

    public function getTestField()
    {
        return $this->isOrderOpen() ? $this->getProduct()->getTestField() : $this->testField;
    }

    public function renew()
    {
        $result = parent::renew();

        if ($result) {
            $this->setTestField($this->getProduct()->getTestField());
        }

        return $result;
    }

    protected function getDeletedProduct()
    {
        $dumpProduct = parent::getDeletedProduct();
        $dumpProduct->testField = $this->getTestField();

        return $dumpProduct;
    }

    protected function saveItemState(\XLite\Model\Base\IOrderItem $item)
    {
        parent::saveItemState($item);
        $this->setTestField($item->getTestField());
    }

    protected function resetItemState()
    {
        parent::resetItemState();
        $this->testField = '';
    }
}
