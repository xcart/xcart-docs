<?php

namespace XLite\Module\Tutorial\Task1Map\View;

/**
 * @ListChild (list="layout.main", weight="370")
 */

class Map extends \XLite\View\AView
{
    public static function getAllowedTargets()
    {
        return ['main'];
    }

    protected function getMapCode()
    {
        return \XLite\Core\Config::getInstance()->Tutorial->Task1Map->map_code
/*
            '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2326.8587126965976!2d48.39623695117495!3d54.32412910862507!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x415d376802559f5f%3A0xdd67fd77c94370fe!2sUlitsa+Mira%2C+32%2C+Ulyanovsk%2C+Ulyanovskaya+oblast&#39;%2C+432011!5e0!3m2!1sen!2sru!4v1530616932723" width="1200" height="450" frameborder="0" style="border:0;" allowfullscreen></iframe>'
*/            
        ;
    }

    public function getCSSFiles()
    {
        return array_merge(
            parent::getCSSFiles(),
            ['modules/Tutorial/Task1Map/css/style.css']
        );
    }

    protected function getDefaultTemplate()
    {
        return 'modules/Tutorial/Task1Map/map.twig';
    }
}