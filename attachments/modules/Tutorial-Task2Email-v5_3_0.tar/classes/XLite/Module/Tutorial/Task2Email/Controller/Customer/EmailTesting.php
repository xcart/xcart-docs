<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\Tutorial\Task2Email\Controller\Customer;

/**
 * EmailTesting
 */
class EmailTesting extends \XLite\Controller\Customer\ACustomer
{
    /**
     * Get target title
     */
    public function getTitle()
    {
        return static::t('Email Testing');
    }

    protected function doActionSend()
    {
        $request = \XLite\Core\Request::getInstance();

        $error = \XLite\Core\Mailer::sendTutorialTestMessage(
            $request->from,
            $request->to,
            $request->subject,
            $request->body           
        );

        if (!is_null($error)) {
            \XLite\Core\TopMessage::getInstance()->addError('Error of test e-mail sending: ' . $error);
        } else {
            \XLite\Core\TopMessage::getInstance()->add('Test e-mail has been successfully sent');
        }

        $this->setReturnURL(
            $this->buildURL('email_testing')
        );
    }    
}
