<?php

namespace XLite\Module\Tutorial\Task2Email\View\Form;

class EmailTesting extends \XLite\View\Form\AForm
{
    protected function getDefaultTarget()
    {
        return 'email_testing';
    }

    protected function getDefaultAction()
    {
        return 'send';
    }

    protected function getDefaultClassName()
    {
        return trim(parent::getDefaultClassName() . ' email-testing-form');
    }
}