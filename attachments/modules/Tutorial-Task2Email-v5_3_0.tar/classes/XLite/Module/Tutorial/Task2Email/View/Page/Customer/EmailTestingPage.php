<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\Tutorial\Task2Email\View\Page\Customer;

/**
 * EmailTestingPage
 *
 * @ListChild (list="center", zone="customer")
 */
class EmailTestingPage extends \XLite\View\AView
{
        
    /**
     * Return list of allowed targets
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('email_testing'));
    }
      
    /**
     * Return widget default template
     */
    public function getDefaultTemplate()
    {
        return 'modules/Tutorial/Task2Email/page/email_testing/body.twig';
    }

    public function getCSSFiles()
    {
        return array_merge(
            parent::getCSSFiles(),
            array(
                'modules/Tutorial/Task2Email/css/style.css'
            )
        );
    }
}
