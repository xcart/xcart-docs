<?php

namespace XLite\Module\Tutorial\Task2Email\View\Model;

class EmailTestingForm extends \XLite\View\Model\AModel
{
    protected $schemaDefault = [
        'from' => [
            self::SCHEMA_CLASS      => 'XLite\View\FormField\Input\Text\Email',
            self::SCHEMA_LABEL      => 'From',
            self::SCHEMA_REQUIRED   => true,
        ],        
        'to' => [
            self::SCHEMA_CLASS      => 'XLite\View\FormField\Input\Text\Email',
            self::SCHEMA_LABEL      => 'To',
            self::SCHEMA_REQUIRED   => true,
        ],     
        'subject' => [
            self::SCHEMA_CLASS      => 'XLite\View\FormField\Input\Text',
            self::SCHEMA_LABEL      => 'Subject',
            self::SCHEMA_REQUIRED   => true,            
        ],
        'body' => [
            self::SCHEMA_CLASS      => 'XLite\View\FormField\Textarea\Simple',
            self::SCHEMA_LABEL      => 'Body',
            self::SCHEMA_REQUIRED   => true,            
        ],
    ];

    protected function getDefaultModelObject()
    {
        return null;
    }

    protected function getFormClass()
    {
        return 'XLite\Module\Tutorial\Task2Email\View\Form\EmailTesting';
    }
    
    protected function getFormButtons()
    {
        $result = parent::getFormButtons();

        $result['submit'] = new \XLite\View\Button\Submit(
            [
                \XLite\View\Button\AButton::PARAM_LABEL    => 'Send',
                \XLite\View\Button\AButton::PARAM_BTN_TYPE => 'btn  regular-main-button  submit',
            ]
        );

        return $result;
    }

}