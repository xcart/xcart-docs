<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tutorial\Task2Email\Core;

/**
 * Mailer core class
 */
abstract class Mailer extends \XLite\Core\Mailer implements \XLite\Base\IDecorator
{
    public static function sendTutorialTestMessage($from, $to, $subject = '', $body = '')
    {
        static::register([
            'subject' => $subject,  
            'body' => $body,
        ]);

        static::compose(
            'Task2Email',
            $from,
            $to,
            'modules/Tutorial/Task2Email/email',
            array(),
            true,
            \XLite::CUSTOMER_INTERFACE
        );

        return static::getMailer()->getLastError();
    }    
}