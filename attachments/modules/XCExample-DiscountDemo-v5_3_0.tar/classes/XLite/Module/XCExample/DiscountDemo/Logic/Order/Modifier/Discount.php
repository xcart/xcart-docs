<?php

namespace XLite\Module\XCExample\DiscountDemo\Logic\Order\Modifier;

class Discount extends \XLite\Logic\Order\Modifier\Discount
{
    const MODIFIER_CODE = 'DISCOUNT';

    protected $type = \XLite\Model\Base\Surcharge::TYPE_DISCOUNT;

    protected $code = self::MODIFIER_CODE;

    public function calculate()
    {
        $surcharge = null;
        $discount = $this->getOrder()->getSubtotal() * 0.1;
        $surcharge = $this->addOrderSurcharge($this->code, $discount * -1);
        $this->distributeDiscount($discount);
        return $surcharge;
    }
}