<?php

namespace XLite\Module\XCExample\AllProductsDemo\View\Pager\Customer\Product;

class Product extends \XLite\View\Pager\Customer\Product\AProduct
{
}