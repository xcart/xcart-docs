<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\AllProductsDemo\Controller\Customer;

/**
 * All products controller
 */
class AllProducts extends \XLite\Controller\Customer\ACustomer
{
}