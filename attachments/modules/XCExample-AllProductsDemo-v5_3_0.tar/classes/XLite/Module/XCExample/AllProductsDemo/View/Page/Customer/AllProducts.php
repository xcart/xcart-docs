<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\AllProductsDemo\View\Page\Customer;

/**
 * All products page view
 *
 * @ListChild (list="center")
 */
class AllProducts extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('all_products'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/AllProductsDemo/page/all_products/body.twig';
    }

}