<?php 

namespace XLite\Module\XCExample\AllProductsDemo\View\ItemsList\Product\Customer; 

/** 
 * 
 * @ListChild (list="center.bottom", zone="customer", weight="300") 
 */ 

class AllProducts extends \XLite\View\ItemsList\Product\Customer\ACustomer
{ 
    protected static function getWidgetTarget()
    {
        return 'all_products';
    }

    public static function getAllowedTargets()  
    {  
        $result = parent::getAllowedTargets();

        $result[] = self::getWidgetTarget();

        return $result;
    } 

    protected function getData(\XLite\Core\CommonCell $cnd, $countOnly = false)
    {
        return \XLite\Core\Database::getRepo('\XLite\Model\Product')->search(
            $cnd,
            $countOnly
        );
    }

    protected function getPagerClass()
    {
        return 'XLite\Module\XCExample\AllProductsDemo\View\Pager\Customer\Product\Product';
    }
    
}