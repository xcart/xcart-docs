<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\SessionDemo\Controller\Customer;

/**
 * SessionDemo
 */
class SessionDemo extends \XLite\Controller\Customer\ACustomer
{
    public function handleRequest()
    {
        $sessionValue = \XLite\Core\Request::getInstance()->session_value;

        if (!empty($sessionValue)) {
            \XLite\Core\Session::getInstance()->session_value = $sessionValue;
        }

        parent::handleRequest();
    }

    public function getSessionValue() 
    {
        if (!empty(\XLite\Core\Session::getInstance()->session_value)) {
            return \XLite\Core\Session::getInstance()->session_value;
        }

        return null;
    }    
}