<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\SessionDemo\View\Page\Customer;

/**
 * SessionDemoPage
 *
 * @ListChild (list="center", zone="customer")
 */
class SessionDemoPage extends \XLite\View\AView
{
        
    /**
     * Return list of allowed targets
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('session_demo'));
    }
      
    /**
     * Return widget default template
     */
    public function getDefaultTemplate()
    {
        return 'modules/XCExample/SessionDemo/page/session_demo/body.twig';
    }
}
