<?php 

namespace XLite\Module\Tony\ProductsDemo\View\ItemsList\Product\Customer; 

/** 
 * 
 * @ListChild (list="center.bottom", zone="customer", weight="300") 
 */ 

class AllProducts extends \XLite\View\ItemsList\Product\Customer\Category\ACategory 
{ 
    protected $allProducts = null;

    public static function getAllowedTargets()  
    {  
        $return = array('all_products'); 

        return $return;  
    } 

    protected function getData(\XLite\Core\CommonCell $cnd, $countOnly = false) 
    { 
        if (!isset($this->allProducts)) { 
            $this->allProducts = \XLite\Core\Database::getRepo('XLite\Model\Product')->findAll(); 
        } 

        return true == $countOnly 
            ? count($this->allProducts) 
            : $this->allProducts; 
    } 
}