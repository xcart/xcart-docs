<?php

namespace XLite\Module\XCExample\PopupDemo\View\Page\Customer;

/**
 * @ListChild (list="center")
 */

class ExamplePopupDemo extends \XLite\View\AView
{
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('example_popup_demo'));
    }

    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/PopupDemo/page/example_popup_demo/body.twig';
    }
}