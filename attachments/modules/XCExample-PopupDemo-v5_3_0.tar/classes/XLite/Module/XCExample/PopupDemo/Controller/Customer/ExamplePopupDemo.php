<?php

namespace XLite\Module\XCExample\PopupDemo\Controller\Customer;

class ExamplePopupDemo extends \XLite\Controller\Customer\ACustomer
{
    public function getTitle()
    {
        return 'Example: pop-up widget';
    }
}