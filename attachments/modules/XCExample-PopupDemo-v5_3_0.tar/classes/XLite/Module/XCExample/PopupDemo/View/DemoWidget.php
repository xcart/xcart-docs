<?php

namespace XLite\Module\XCExample\PopupDemo\View;

class DemoWidget extends \XLite\View\AView
{
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('example_popup_demo'));
    }

    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/PopupDemo/page/example_popup_demo/demo_widget.twig';
    }

    protected function getCartQuantity()
    {
        return \XLite\Model\Cart::getInstance()->countQuantity();
    }

    protected function getDisplaySubtotal()
    {
        return \XLite\Model\Cart::getInstance()->getDisplaySubtotal();
    }

    protected function getCurrency()
    {
        return \XLite\Model\Cart::getInstance()->getCurrency();
    }

    protected function hasItems()
    {
        return (bool) \XLite\Model\Cart::getInstance()->countItems();
    }

    protected function getItems()
    {
        return array_slice(
            \XLite\Model\Cart::getInstance()->getItems()->toArray(),
            0,
            min(5, \XLite\Model\Cart::getInstance()->countItems())
        );
    }
}