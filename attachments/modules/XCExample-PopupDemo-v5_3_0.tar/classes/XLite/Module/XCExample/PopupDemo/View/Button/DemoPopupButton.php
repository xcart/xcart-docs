<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\PopupDemo\View\Button;

/**
 * Demo popup widget
 */
class DemoPopupButton extends \XLite\View\Button\APopupButton
{
    /**
     * getJSFiles
     *
     * @return array
     */
    public function getJSFiles()
    {
        $list = parent::getJSFiles();
        $list[] = 'modules/XCExample/PopupDemo/page/example_popup_demo/popup_button.js';

        return $list;
    }

    /**
     * Return URL parameters to use in AJAX popup
     *
     * @return array
     */
    protected function prepareURLParams()
    {
        return array(
            'target'       => 'example_popup_demo',
            'widget'       => '\XLite\Module\XCExample\PopupDemo\View\DemoWidget',
        );
    }

    /**
     * Return CSS classes
     *
     * @return string
     */
    protected function getClass()
    {
        return parent::getClass() . ' demo-popup';
    }

}
