/* vim: set ts=2 sw=2 sts=2 et: */

/**
 * Demo popup button controller
 */

function DemoPopupButton()
{
  DemoPopupButton.superclass.constructor.apply(this, arguments);
}

extend(DemoPopupButton, PopupButton);

DemoPopupButton.prototype.pattern = '.demo-popup';

DemoPopupButton.prototype.callback = function(selector)
{
  PopupButton.prototype.callback.apply(this, arguments);

  // Some autoloading could be added
}

core.autoload(DemoPopupButton);
