<?php

namespace XLite\Module\Tony\DecoratorDemo\View\ItemsList\Product\Customer;

abstract class ACustomer extends \XLite\View\ItemsList\Product\Customer\ACustomer implements \XLite\Base\IDecorator
{
    protected function isQuickLookEnabled()
    {
        return false;
    }
}