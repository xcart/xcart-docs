<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\PaymentShippingDependency\Model;

/**
 * Class represents an order
 */
class Order extends \XLite\Model\Order implements \XLite\Base\IDecorator
{
	public function getPaymentMethods()
    {
        if (0 < $this->getOpenTotal()) {

            $list = parent::getPaymentMethods();

            $shipping = \XLite\Core\Database::getRepo('XLite\Model\Shipping\Method')->find($this->getShippingId());

            $shipping = ($shipping && $shipping->getParentMethod()) ? $shipping->getParentMethod() : $shipping;

            foreach ($list as $i => $method) {
                if (!$method->isEnabled() || !$method->getProcessor()->isApplicable($this, $method) 
                	|| ($shipping && $shipping->getName() == 'Local shipping' && $method->getMethodId() == 2)) {
                    unset($list[$i]);
                }
            }

        } else {
            $list = array();
        }

        return $list;
    }
}
