<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ModelEditingDemo\Controller\Admin;

/**
 * Product edit controller
 */
class ProductEdit extends \XLite\Controller\Admin\AAdmin
{
    protected $params = array('target', 'product_id');
 
    protected function getModelFormClass()
    {
        return 'XLite\Module\Tony\ModelEditingDemo\View\Model\Product';
    }
 
    protected function doActionUpdate()
    {
        $this->getModelForm()->performAction('modify');
 
        if ($this->getProductId() === 0) {
            $this->setReturnURL(
                $this->buildURL(
                    'product_edit',
                    '',
                    array('product_id' => $this->getModelForm()->getModelObject()->getId())
                )
            );
        }
    }

    public function getProductId()
    {
        return \XLite\Core\Request::getInstance()->product_id ?: 0;
    }
}