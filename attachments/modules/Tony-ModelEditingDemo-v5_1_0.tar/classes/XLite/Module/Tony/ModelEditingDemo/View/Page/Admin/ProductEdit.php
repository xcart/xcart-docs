<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ModelEditingDemo\View\Page\Admin;

/**
 * Product edit page view
 *
 * @ListChild (list="admin.center", zone="admin")
 */
class ProductEdit extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('product_edit'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/Tony/ModelEditingDemo/page/product_edit/body.tpl';
    }
}