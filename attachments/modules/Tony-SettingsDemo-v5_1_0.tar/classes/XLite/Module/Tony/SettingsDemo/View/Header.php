<?php

namespace XLite\Module\Tony\SettingsDemo\View;

/**
 * @ListChild (list="head")
 */
 
class Header extends \XLite\View\AView
{
	protected function getDefaultTemplate() 
	{
		return 'modules/Tony/SettingsDemo/html_code.tpl';
	}

	public function getHtmlCode()
	{
		return \XLite\Core\Config::getInstance()->Tony->SettingsDemo->html_code;
	}
}