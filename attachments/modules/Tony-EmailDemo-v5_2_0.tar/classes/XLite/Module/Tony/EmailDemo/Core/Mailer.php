<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\EmailDemo\Core;

/**
 * Mailer core class
 */
abstract class Mailer extends \XLite\Core\Mailer implements \XLite\Base\IDecorator
{
    public static function sendMyEmail()
    {
        $from = 'bit-bucket@x-cart.com';
        $to = 'bit-bucket@x-cart.com';
        $dir = 'modules/Tony/EmailDemo/message';

        static::compose(
            static::TYPE_TEST_EMAIL,
            $from,
            $to,
            $dir,
            array(),
            true,
            \XLite::ADMIN_INTERFACE
        );
    }
}