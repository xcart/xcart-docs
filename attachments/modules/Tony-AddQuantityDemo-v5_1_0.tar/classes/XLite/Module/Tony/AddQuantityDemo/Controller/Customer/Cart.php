<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\AddQuantityDemo\Controller\Customer;

/**
 * \XLite\Controller\Customer\Cart
 */
abstract class Cart extends \XLite\Controller\Customer\Cart implements \XLite\Base\IDecorator
{
    protected function addItem($item)
    {
        if (0 == $item->getAmount() % 2) {
            $result = parent::addItem($item);
        } else {
            $result = false;
            \XLite\Core\TopMessage::addWarning('You can add only even number of this product (2, 4, 6, etc).');
        }

        return $result;
    }
}