<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\AddQuantityDemo\View;

/**
 * Abstract widget
 */
abstract class AView extends \XLite\View\AView implements \XLite\Base\IDecorator
{
    protected function getThemeFiles($adminZone = null)
    {
        $list = parent::getThemeFiles($adminZone);

        if (\XLite::getController() instanceof \XLite\Controller\Customer\Product) {
            $list[static::RESOURCE_JS][] = 'modules/Tony/AddQuantityDemo/js/script.js';
        }

        return $list;
    }
}