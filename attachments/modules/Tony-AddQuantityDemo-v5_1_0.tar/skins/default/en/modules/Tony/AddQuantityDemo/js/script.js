$(".product-buttons .add2cart").click(
    function() 
    {
        if (parseInt($(".product-buttons input.quantity").val()) % 2 != 0) {
            alert('You can add only even number of this product (2, 4, 6, etc).');
            event.preventDefault();
        }
    }
)