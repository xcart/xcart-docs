<?php

namespace XLite\Module\Tony\PageDemo\Controller\Admin;

class TonyCustom extends \XLite\Controller\Admin\AAdmin
{
}