<?php

namespace XLite\Module\XCExample\ItemsListStickyPanel\View\Button;

class DropdownDemo extends \XLite\View\Button\Dropdown\ADropdown
{
    protected function defineAdditionalButtons()
    {
        return [
            'demo_two' => [
                'params'    => [
                    'action'    => 'demo_two',
                    'label'     => 'Demo Two',
                    'style'     => 'always-enabled link',
                ],
                'position'  => 100,
            ],
            'divider' => [
                'class'     => 'XLite\View\Button\Dropdown\Divider',
                'params'    => [
                ],
                'position'  => 200,
            ],
            'demo_three'    => [
                'params'    => [
                    'action'    => 'demo_three',
                    'label'     => 'Demo Three',
                    'style'     => 'always-enabled link',
                ],
                'position'  => 300,
            ],
        ];
    }
}