<?php

namespace XLite\Module\XCExample\ItemsListStickyPanel\Model\Repo;

class StickyPanelDemoEntity extends \XLite\Model\Repo\ARepo
{

}