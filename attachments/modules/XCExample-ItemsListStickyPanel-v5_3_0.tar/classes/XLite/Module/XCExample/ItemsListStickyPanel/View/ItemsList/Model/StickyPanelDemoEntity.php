<?php

namespace XLite\Module\XCExample\ItemsListStickyPanel\View\ItemsList\Model;

class StickyPanelDemoEntity extends \XLite\View\ItemsList\Model\Table
{
    protected function defineColumns()
    {
        return array(
            'body' => array(
                static::COLUMN_CLASS    => 'XLite\View\FormField\Inline\Input\Text',
                static::COLUMN_NAME     => static::t('Entity body'),
                static::COLUMN_ORDERBY  => 100,
            ),

        );
    }

    public function getCSSFiles()
    {
        return array_merge(
            parent::getCSSFiles(),
            ['modules/XCExample/ItemsListStickyPanel/css/style.css']
        );
    }

    protected function defineRepositoryName()
    {
        return 'XLite\Module\XCExample\ItemsListStickyPanel\Model\StickyPanelDemoEntity';
    }

    protected function isSwitchable()
    {
        return true;
    }

    protected function isRemoved()
    {
        return true;
    } 

    protected function isInlineCreation()
    {
        return static::CREATE_INLINE_BOTTOM;
    }

    protected function getCreateURL()
    {
        return \XLite\Core\Converter::buildUrl('sticky_panel_demo');
    }

    protected function isSelectable()
    {
        return true;
    }

    protected function wrapWithFormByDefault()
    {
        return true;
    }

    protected function getFormTarget()
    {
        return 'sticky_panel_demo';
    }

    protected function getPanelClass()
    {
/*        
        $result = parent::getPanelClass();

        var_dump($result);

        return $result;
*/
        return 'XLite\Module\XCExample\ItemsListStickyPanel\View\StickyPanel\DemoEntity';
    }
}