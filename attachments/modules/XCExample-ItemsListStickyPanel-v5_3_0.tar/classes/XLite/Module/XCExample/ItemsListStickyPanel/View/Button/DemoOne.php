<?php

namespace XLite\Module\XCExample\ItemsListStickyPanel\View\Button;

class DemoOne extends \XLite\View\Button\Regular
{
}