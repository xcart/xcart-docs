<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\ItemsListStickyPanel\Controller\Admin;

/**
 * StickyPanelDemo
 */
class StickyPanelDemo extends \XLite\Controller\Admin\AAdmin
{ 
    /**
     * Get target title
     */
    public function getTitle()
    {
        return static::t('Sticky Panel Demo');
    }

    public function handleRequest()
    {
        if ($this->getAction()) {
            // print_r(\XLite\Core\Request::getInstance());
            \XLite\Core\TopMessage::addInfo('We submitted the form with action=' . $this->getAction());
        }

        parent::handleRequest();
    }
}
