<?php

namespace XLite\Module\XCExample\ItemsListStickyPanel\View\StickyPanel;

class DemoEntity extends \XLite\View\StickyPanel\ItemsListForm
{
    protected function getSaveWidgetLabel()
    {
        return static::t('New save changes');
    }

    protected function getSaveWidgetStyle()
    {
        return parent::getSaveWidgetStyle() . ' green-main-button';
    }

    public function getCSSFiles()
    {
        return array_merge(
            parent::getCSSFiles(),
            ['modules/XCExample/ItemsListStickyPanel/css/style.css']
        );
    }

    protected function defineButtons()
    {
        $list = parent::defineButtons();

        $list['mybutton'] = $this->getWidget(
            [
                'action'    => 'demo_one',
                'style'     => 'always-enabled',
                'label'     => 'Demo Button 1',
            ],
            'XLite\Module\XCExample\ItemsListStickyPanel\View\Button\DemoOne'
        );

        $list['dropdown'] = $this->getWidget(
            [
                'label'             => 'Dropdown Demo',
                'style'             => 'always-enabled more-action',
                'useCaretButton'    => false,
                'dropDirection'     => 'dropdown',
            ],
            'XLite\Module\XCExample\ItemsListStickyPanel\View\Button\DropdownDemo'
        );

        return $list;
    }

    protected function defineAdditionalButtons()
    {
        return [
            'dropdown_two' => [
                'class'     => 'XLite\Module\XCExample\ItemsListStickyPanel\View\Button\DropdownDemo',
                'params'    => [
                    'label'             => 'Dropdown Demo Additional',
                    'style'             => 'hide-on-disable hidden more-action',
                    'useCaretButton'    => false,
                    'dropDirection'     => 'dropup',
                ],
                'position'  => 100,
            ],
        ];
    }
}