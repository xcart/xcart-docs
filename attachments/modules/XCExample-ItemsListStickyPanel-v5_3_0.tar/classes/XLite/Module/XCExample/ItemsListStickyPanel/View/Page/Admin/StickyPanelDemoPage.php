<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\ItemsListStickyPanel\View\Page\Admin;

/**
 * StickyPanelDemoPage
 *
 * @ListChild (list="admin.center", zone="admin")
 */
class StickyPanelDemoPage extends \XLite\View\AView
{
        
    /**
     * Return list of allowed targets
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('sticky_panel_demo'));
    }
      
    /**
     * Return widget default template
     */
    public function getDefaultTemplate()
    {
        return 'modules/XCExample/ItemsListStickyPanel/page/sticky_panel_demo/body.twig';
    }
}
