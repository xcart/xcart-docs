<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\AdminMenuDemo\View\Menu\Admin;

/**
 * Top menu widget
 */
class TopMenu extends \XLite\View\Menu\Admin\TopMenu implements \XLite\Base\IDecorator
{
	protected function defineItems() 
	{
		$menu = parent::defineItems();

		$menu['promotions'][self::ITEM_CHILDREN] += array (
			'google' => array (
			    self::ITEM_TITLE	=> 'Google menu item',
                self::ITEM_LINK   	=> 'http://google.com',
                self::ITEM_WEIGHT   => 500,
                ),
			);

		$menu['promotions'][self::ITEM_CHILDREN] += array (
			'products' => array (
			    self::ITEM_TITLE	=> 'Another link to products',
                self::ITEM_TARGET   => 'product_list',
                self::ITEM_WEIGHT   => 600,
            	),
			);

		if (!isset($menu['my-menu'])) {
			$menu['my-menu'] = array (
				self::ITEM_TITLE 	=> 'My custom menu',
				self::ITEM_TARGET 	=> 'product_list',
				self::ITEM_WEIGHT 	=> 300,
				self::ITEM_CHILDREN => array(),
			);
		}

		$menu['my-menu'][self::ITEM_CHILDREN] += array (
			'products' => array (
				self::ITEM_TITLE 	=> 'Products in custom menu',
				self::ITEM_TARGET 	=> 'product_list',
				self::ITEM_WEIGHT 	=> 100,
				),
			);

		return $menu;
	}
}