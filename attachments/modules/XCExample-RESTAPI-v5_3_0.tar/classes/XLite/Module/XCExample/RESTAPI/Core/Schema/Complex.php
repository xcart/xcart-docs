<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\RESTAPI\Core\Schema;

/**
 * Complex schema
 */
class Complex extends \XLite\Module\XC\RESTAPI\Core\Schema\Complex implements \XLite\Base\IDecorator
{
    /**
     * Convert model (order)
     *
     * @param \XLite\Model\Order $model Order
     * @param boolean $withAssociations Convert with associations
     *
     * @return array
     */
    protected function convertModelOrder(\XLite\Model\Order $model, $withAssociations)
    {
        $data = parent::convertModelOrder($model, $withAssociations);

        $profile = $model->getOrigProfile() ?: $model->getProfile();
        
        if (
            !empty($data['billingInfo'])
            && $profile
            && $profile->getBillingAddress()
        ) {
            $data['billingInfo']['phone'] = $profile->getBillingAddress()->getPhone();
        }
        
        if (
            !empty($data['shippingInfo'])
            && $profile
            && $profile->getShippingAddress()
        ) {
            $data['shippingInfo']['phone'] = $profile->getShippingAddress()->getPhone();
        }

        $transactions = $model->getPaymentTransactions();

        if ($transactions) {
            $PONumber = '';
            foreach ($transactions as $transaction) {
                $transactionData = $transaction->getDataCell('po_number');
                if ($transactionData) {
                    $PONumber = $transactionData->getValue();
                }
            }
            $data['PONumber'] = $PONumber;
        }

        
        return $data;
    }
}