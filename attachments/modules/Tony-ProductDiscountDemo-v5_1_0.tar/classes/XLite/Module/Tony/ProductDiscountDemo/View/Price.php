<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ProductDiscountDemo\View;

/**
 * Product price
 */
abstract class Price extends \XLite\View\Price implements \XLite\Base\IDecorator
{
    protected function getOldPrice()
    {
        return $this->getProduct()->getPriceBeforeMyProductDiscount();
    }

    protected function isMyDiscount()
    {
        return $this->getProduct()->isMyDiscount();
    }
}