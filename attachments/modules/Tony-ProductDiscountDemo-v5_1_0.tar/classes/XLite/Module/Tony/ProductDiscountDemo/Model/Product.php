<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ProductDiscountDemo\Model;

/**
 * The "product" model class
 */
abstract class Product extends \XLite\Model\Product implements \XLite\Base\IDecorator
{
    protected $priceBeforeMyProductDiscount = null;

    public function getClearPrice()
    {
        $price = parent::getClearPrice();

        if ($this->isMyDiscount()) {
            $this->setPriceBeforeMyProductDiscount($price);
            $price = 0.9 * $price;
        }

        return $price;
    }

    protected function setPriceBeforeMyProductDiscount($price)
    {
        $this->priceBeforeMyProductDiscount = $price;
    }

    public function getPriceBeforeMyProductDiscount()
    {
        return $this->priceBeforeMyProductDiscount;
    }

    public function isMyDiscount() 
    {
        return 0 === stripos($this->getName(), 'A');
    }
}