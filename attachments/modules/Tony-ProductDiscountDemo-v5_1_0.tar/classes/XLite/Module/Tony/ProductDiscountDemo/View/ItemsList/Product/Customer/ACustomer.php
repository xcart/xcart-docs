<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ProductDiscountDemo\View\ItemsList\Product\Customer;

/**
 * ACustomer
 */
abstract class ACustomer extends \XLite\View\ItemsList\Product\Customer\ACustomer implements \XLite\Base\IDecorator
{
    protected function getLabels(\XLite\Model\Product $product)
    {
        $labels = parent::getLabels($product);

        if ($product->isMyDiscount()) {
            $labels += array('my-discount' => '10% off');
        }

        return $labels;
    }
}