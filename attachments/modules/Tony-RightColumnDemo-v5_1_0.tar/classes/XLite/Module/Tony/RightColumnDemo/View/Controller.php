<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\RightColumnDemo\View;

/**
 * Controller main widget
 */
abstract class Controller extends \XLite\View\Controller implements \XLite\Base\IDecorator
{
    public static function isSidebarSecondVisible()
    {
        return !\XLite::isAdminZone() ? true : parent::isSidebarSecondVisible();
    }

    public static function isSidebarFirstVisible()
    {
        return !\XLite::isAdminZone() ? false: parent::isSidebarFirstVisible();
    }
}
