<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\SessionDemo\Controller\Customer;

/**
 * Session demo controller
 */
class SessionDemo extends \XLite\Controller\Customer\ACustomer
{
    public function handleRequest()
    {
        $sessionValue = \XLite\Core\Request::getInstance()->session_value;

        if (!empty($sessionValue)) {
            \XLite\Core\Session::getInstance()->s_value = $sessionValue;
        }

        parent::handleRequest();
    }

    public function getSessionValue() 
    {
        $return = '';

        if (!empty(\XLite\Core\Session::getInstance()->s_value)) {
            $return = \XLite\Core\Session::getInstance()->s_value;
        }

        return $return;
    }
}