<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\SessionDemo\View\Page\Customer;

/**
 * Session demo page view
 *
 * @ListChild (list="center")
 */
class SessionDemo extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('session_demo'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/Tony/SessionDemo/page/session_demo/body.tpl';
    }

}