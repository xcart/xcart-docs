<?php
// vim: set ts=4 sw=4 sts=4 et:
 
namespace XLite\Module\XCExample\PersistentProductPropertyDemo\View\FormModel\Product;
 
/**
 * Product form model
 */
abstract class Info extends \XLite\View\FormModel\Product\Info implements \XLite\Base\IDecorator
{
    protected function defineFields()
    {
        $schema = parent::defineFields();
 
        $schema['default']['myMessage'] = [
            'label'     => static::t('My message'),
            'position'  => 900,
        ];
 
        return $schema;
    }
 
}