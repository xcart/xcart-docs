<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\PersistentProductPropertyDemo\Model;

/**
 * Something customer can put into his cart
 */
abstract class OrderItem extends \XLite\Model\OrderItem implements \XLite\Base\IDecorator
{
    /**
     * @Column (type="string")
     */
    protected $myMessage;

    public function getMyMessage()
    {
        return $this->isOrderOpen() ? $this->getProduct()->getMyMessage() : $this->myMessage;
    }

    public function setMyMessage($value)
    {
        $this->myMessage = $value;
    }    

    public function renew()
    {
        $result = parent::renew();

        if ($result) {
            $this->setTestField($this->getProduct()->getMyMessage());
        }

        return $result;
    }

    protected function saveItemState(\XLite\Model\Base\IOrderItem $item)
    {
        parent::saveItemState($item);

        $this->myMessage = $item->getMyMessage();
    }

    protected function resetItemState()
    {
        parent::resetItemState();
        
        $this->myMessage = '';
    }

    protected function getDeletedProduct()
    {
        $dumpProduct = parent::getDeletedProduct();
        $dumpProduct->setMyMessage($this->getMyMessage());

        return $dumpProduct;
    }

}