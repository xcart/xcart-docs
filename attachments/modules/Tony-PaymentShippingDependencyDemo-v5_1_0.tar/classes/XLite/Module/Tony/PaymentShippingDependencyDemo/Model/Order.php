<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\PaymentShippingDependencyDemo\Model;

/**
 * Class represents an order
 */
abstract class Order extends \XLite\Model\Order implements \XLite\Base\IDecorator
{
	public function getPaymentMethods()
    {
        if (0 < $this->getOpenTotal()) {

            $list = \XLite\Core\Database::getRepo('XLite\Model\Payment\Method')
                ->findAllActive();

            foreach ($list as $i => $method) {
                if (!$method->isEnabled() || !$method->getProcessor()->isApplicable($this, $method) 
                	|| $this->getShippingId() == 2 && $method->getMethodId() == 132) {
                    unset($list[$i]);
                }
            }

        } else {
            $list = array();
        }

        return $list;
    }
}
