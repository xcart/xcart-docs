<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\ModelEditing\Controller\Admin;

/**
 * Product edit controller
 */
class ExampleProductEdit extends \XLite\Controller\Admin\AAdmin
{
    use \XLite\Controller\Features\FormModelControllerTrait;

    /**
     * @var array
     */
    protected $params = array('target', 'product_id');

    /**
     * @var \XLite\Model\Product
     */
    protected $product;

    /**
     * @return integer
     */
    public function getProductId()
    {
        return (int) \XLite\Core\Request::getInstance()->product_id ?: 0;
    }

    /**
     * @return \XLite\Model\Product
     */
    public function getProduct()
    {
        if (null === $this->product) {
            $product = \XLite\Core\Database::getRepo('\XLite\Model\Product')->find($this->getProductId());
            $this->product = $product ?: new \XLite\Model\Product();
        }

        return $this->product;
    }

    /**
     * @return \XLite\Model\DTO\Base\ADTO
     */
    public function getFormModelObject()
    {
        return new \XLite\Module\XCExample\ModelEditing\Model\DTO\ProductEdit($this->getProduct());
    }

    protected function doActionUpdate()
    {
        $dto = $this->getFormModelObject();
        $product = $this->getProduct();

        $formModel = new \XLite\Module\XCExample\ModelEditing\View\FormModel\ProductEdit(['object' => $dto]);
        $form = $formModel->getForm();

        $data = \XLite\Core\Request::getInstance()->getData();
        $rawData = \XLite\Core\Request::getInstance()->getNonFilteredData();

        $form->submit($data[$this->formName]);

        if ($form->isValid()) {
            $dto->populateTo($product, $rawData[$this->formName]);
            \XLite\Core\Database::getEM()->persist($product);
            \XLite\Core\Database::getEM()->flush();

        } else {
            $this->saveFormModelTmpData($rawData[$this->formName]);
        }

        $productId = $product->getProductId() ?: $this->getProductId();

        $params = $productId ? ['product_id' => $productId] : [];

        $this->setReturnURL($this->buildURL('example_product_edit', '', $params));
    }
}
