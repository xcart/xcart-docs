<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\SearchRepoDemo\Model\Repo;

/**
 * The "product" model repository
 */
abstract class Product extends \XLite\Model\Repo\Product implements \XLite\Base\IDecorator
{
    protected function prepareCndMoreExpensiveThan20(\Doctrine\ORM\QueryBuilder $queryBuilder, $value)
    {
        $result = $queryBuilder;

        if ($value) {
            $result
                ->andWhere('p.price > :price')
                ->setParameter('price', 20);
        }

        return $result;
    }

    protected function prepareCndMoreThan(\Doctrine\ORM\QueryBuilder $queryBuilder, $value)
    {
        $result = $queryBuilder;

        if ($value > 0) {
            $result
                ->andWhere('p.amount > :amount')
                ->setParameter('amount', $value);
        }

        return $result;
    }
}