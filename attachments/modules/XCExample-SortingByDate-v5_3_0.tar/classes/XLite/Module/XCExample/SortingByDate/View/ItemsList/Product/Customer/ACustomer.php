<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\SortingByDate\View\ItemsList\Product\Customer;

/**
 * ACustomer
 */
abstract class ACustomer extends \XLite\View\ItemsList\Product\Customer\ACustomer implements \XLite\Base\IDecorator
{
    public function __construct(array $params = array())
    {
        parent::__construct($params);

        $this->sortByModes = array(
            'p.arrivalDate' => 'Date',
        ) + $this->sortByModes;
    }
}