<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\SearchRepoDemo\Model\Repo;

/**
 * The "product" model repository
 */
abstract class Product extends \XLite\Model\Repo\Product implements \XLite\Base\IDecorator
{
    const P_MY_COND = 'myCond';

    protected function getHandlingSearchParams()
    {
        $params = parent::getHandlingSearchParams();

        $params[] = self::P_MY_COND;

        return $params;
    }

    protected function prepareCndMyCond(\Doctrine\ORM\QueryBuilder $queryBuilder, $value)
    {
        $result = $queryBuilder;

        if ($value) {
            $result
                ->andWhere('p.product_id < :product_id')
                ->setParameter('product_id', 20);
        }

        return $result;
    }
}