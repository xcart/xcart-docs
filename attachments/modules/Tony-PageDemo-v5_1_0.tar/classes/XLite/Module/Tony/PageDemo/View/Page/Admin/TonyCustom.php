<?php

namespace XLite\Module\Tony\PageDemo\View\Page\Admin;

/**
 * @ListChild (list="admin.center", zone="admin")
 */

class TonyCustom extends \XLite\View\AView
{
	public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('tony_custom'));
    }

    protected function getDefaultTemplate()
    {
        return 'modules/Tony/PageDemo/page/tony_custom/body.tpl';
    }
}