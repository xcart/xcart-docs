<?php

namespace XLite\Module\Tony\PageDemo\Controller\Customer;

class TonyCustom extends \XLite\Controller\Customer\ACustomer
{
	
}