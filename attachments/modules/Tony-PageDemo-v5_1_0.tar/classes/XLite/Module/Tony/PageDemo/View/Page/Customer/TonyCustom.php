<?php

namespace XLite\Module\Tony\PageDemo\View\Page\Customer;

/**
 * @ListChild (list="center")
 */

class TonyCustom extends \XLite\View\AView
{
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('tony_custom'));
    }

    protected function getDefaultTemplate()
    {
        return 'modules/Tony/PageDemo/page/tony_custom/body.tpl';
    }
}