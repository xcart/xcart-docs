<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\FormFieldDemo\View\Page\Admin;

/**
 * Form field page view
 *
 * @ListChild (list="admin.center", zone="admin")
 */
class FormField extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('form_field'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/FormFieldDemo/page/form_field/body.twig';
    }

}