<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ItemsListAdminDemo\View\Page\Admin;

/**
 * Items list demo page view
 *
 * @ListChild (list="admin.center", zone="admin")
 */
class ItemsListDemo extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('items_list_demo'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/ItemsListAdminDemo/page/items_list_demo/body.twig';
    }

}