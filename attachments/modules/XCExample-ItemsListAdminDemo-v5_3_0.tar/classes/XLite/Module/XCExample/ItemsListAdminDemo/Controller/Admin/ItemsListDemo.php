<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ItemsListAdminDemo\Controller\Admin;

/**
 * Items list demo controller
 */
class ItemsListDemo extends \XLite\Controller\Admin\AAdmin
{
}