/*
    js code for customer area
*/