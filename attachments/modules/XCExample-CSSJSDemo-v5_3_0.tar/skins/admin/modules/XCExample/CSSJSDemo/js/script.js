/*
    js code for admin area
*/