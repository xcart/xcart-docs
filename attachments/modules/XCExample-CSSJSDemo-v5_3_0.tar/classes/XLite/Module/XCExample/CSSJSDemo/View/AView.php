<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\CSSJSDemo\View;

/**
 * Abstract widget
 */
abstract class AView extends \XLite\View\AView implements \XLite\Base\IDecorator
{
    public function getCSSFiles()
    {
        return array_merge(
            parent::getCSSFiles(),
            array(
                'modules/XCExample/CSSJSDemo/css/style.css',
            )
        );
    }

    public function getJSFiles()
    {
        return array_merge(
            parent::getJSFiles(),
            array(
                'modules/XCExample/CSSJSDemo/js/script.js',
            )
        );
    }
}