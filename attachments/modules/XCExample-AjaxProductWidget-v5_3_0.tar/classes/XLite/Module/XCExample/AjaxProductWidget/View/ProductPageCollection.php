<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\AjaxProductWidget\View;

/**
 * Product page widgets collection
 */
abstract class ProductPageCollection extends \XLite\View\ProductPageCollection implements \XLite\Base\IDecorator
{
    protected function defineWidgetsCollection()
    {
        $widgets = parent::defineWidgetsCollection();

        $widgets = array_merge(
            $widgets,
            [ '\XLite\Module\XCExample\AjaxProductWidget\View\Product\Details\Customer\Widget\Sku' ]
        );

        return array_unique($widgets);
    }    
}
