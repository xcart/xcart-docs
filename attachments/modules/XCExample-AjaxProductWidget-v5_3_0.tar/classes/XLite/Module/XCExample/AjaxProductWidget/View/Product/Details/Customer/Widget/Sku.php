<?php

namespace XLite\Module\XCExample\AjaxProductWidget\View\Product\Details\Customer\Widget;

/**
 * @ListChild (list="product.details.page.info", weight="20")
 */ 
class Sku extends \XLite\View\Product\Details\Customer\Widget
{
    public function getFingerprint()
    {
        return 'widget-fingerprint-product-sku';
    }

    /**
     * Return directory contains the template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/AjaxProductWidget/product/details/sku.twig';
    }

    public function getSku()
    {
        $isProductVariantsEnabled = \XLite\Core\Database::getRepo('XLite\Model\Module')->isModuleEnabled('XC\ProductVariants');

        return $isProductVariantsEnabled && $this->getProductVariant()
            ? $this->getProductVariant()->getDisplaySku()
            : $this->getProduct()->getSKU();
    }
}