<?php

namespace XLite\Module\XCExample\ProductPropertyDemo\Model;

abstract class Product extends \XLite\Model\Product implements \XLite\Base\IDecorator
{
    /**
     * @Column (type="string")
     */
    protected $myMessage;

    public function getMyMessage()
    {
        return $this->myMessage;
    }

    public function setMyMessage($value)
    {
        $this->myMessage = $value;
        return $this;
    }
}