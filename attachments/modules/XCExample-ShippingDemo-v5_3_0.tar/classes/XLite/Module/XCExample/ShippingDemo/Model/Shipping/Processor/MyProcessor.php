<?php

namespace XLite\Module\XCExample\ShippingDemo\Model\Shipping\Processor;

class MyProcessor extends \XLite\Model\Shipping\Processor\AProcessor
{
    /**
     * Returns processor Id
     *
     * @return string
     */
    public function getProcessorId()
    {
        return 'MyProcessor';
    }

    /**
     * Returns processor name
     *
     * @return string
     */
    public function getProcessorName()
    {
        return 'My Processor (header for settings)';
    }    

    /**
     * $data is an object of \XLite\Logic\Order\Modifier\Shipping
     */
    public function getRates($data, $ignoreCache = false)
    {
        $rates = array();

/*
        foreach ($data->getOrder()->getItems() as $item) {
            echo $item->getName();
        }
*/

        $rate = new \XLite\Model\Shipping\Rate();
        $rate->setMethod($this->getShippingMethod());
        $rate->setBaseRate(10.00);

        $rates[] = $rate;

        return $rates;
    }

    protected function getShippingMethod()
    {
        return \XLite\Core\Database::getRepo('\XLite\Model\Shipping\Method')->findOneBy([
            'processor' => $this->getProcessorId(),
            'carrier'   => $this->getProcessorId()
        ]);
    }


    /**
     * Returns url for sign up
     *
     * @return string
     */
    public function getSettingsURL()
    {
        return \XLite\Module\XCExample\ShippingDemo\Main::getSettingsForm();
    }
}