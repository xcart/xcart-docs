<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\ShippingDemo;

/**
 * Main module
 */
abstract class Main extends \XLite\Module\AModule
{
    /**
     * Author name
     *
     * @return string
     */
    public static function getAuthorName()
    {
        return 'XCExample';
    }

    /**
     * Module name
     *
     * @return string
     */
    public static function getModuleName()
    {
        return 'Shipping demo';
    }

    /**
     * Module description
     *
     * @return string
     */
    public static function getDescription()
    {
        return '';
    }

    /**
     * Get module major version
     *
     * @return string
     */
    public static function getMajorVersion()
    {
        return '5.3';
    }

    /**
     * Module version
     *
     * @return string
     */
    public static function getMinorVersion()
    {
        return '0';
    }

    public static function showSettingsForm()
    {
        return true;
    }

    public static function getSettingsForm()
    {
        return \XLite\Core\Converter::buildURL('my_processor');
    }    

    public static function getModuleType()
    {
        return static::MODULE_TYPE_SHIPPING;
    }

    public static function init()
    {
        parent::init();

        \XLite\Model\Shipping::getInstance()->registerProcessor(
            '\XLite\Module\XCExample\ShippingDemo\Model\Shipping\Processor\MyProcessor'
        );
    }
}