<?php

namespace XLite\Module\XCExample\ShippingDemo\Controller\Admin;

class MyProcessor extends \XLite\Controller\Admin\ShippingSettings
{
   /**
    * Get shipping processor
    *
    * @return \XLite\Model\Shipping\Processor\AProcessor
    */
   protected function getProcessor()
   {
       return new \XLite\Module\XCExample\ShippingDemo\Model\Shipping\Processor\MyProcessor();
   }

    protected function getModelFormClass()
    {
        return 'XLite\Module\XCExample\ShippingDemo\View\Model\Settings';
    }   

    protected function getOptionsCategory()
    {
        return 'XCExample\ShippingDemo';
    }    
}