<?php
 
namespace XLite\Module\Tony\SidebarMenu\View;
 
/**
 * @ListChild (list="sidebar.first", zone="customer", weight="500")
 */
 
class MySidebar extends \XLite\View\SideBarBox
{
    protected function getHead()
    {
        return 'My header';
    }
  
   
    protected function getDir()
    {
        return 'modules/Tony/SidebarMenu/menu';
    }
}