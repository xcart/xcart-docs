<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ProductFieldDemo\View\Model;

class Product extends \XLite\View\Model\Product implements \XLite\Base\IDecorator
{
	public function __construct(array $params = array(), array $sections = array())
    {
        parent::__construct($params, $sections);

        $this->schemaDefault += array (
        	'testField' => array(
            	self::SCHEMA_CLASS    => 'XLite\View\FormField\Input\Text',
            	self::SCHEMA_LABEL    => 'Test field',
            	self::SCHEMA_REQUIRED => false,
            	),
        	);
    }
}
