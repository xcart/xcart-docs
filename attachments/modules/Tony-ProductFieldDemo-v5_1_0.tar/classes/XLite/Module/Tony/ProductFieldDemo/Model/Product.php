<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\ProductFieldDemo\Model;

class Product extends \XLite\Model\Product implements \XLite\Base\IDecorator
{
	/**
	 * @Column (type="string", length=32)
	 */
	protected $testField;
}