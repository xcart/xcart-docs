<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\InvoiceChangeDemo\Model\Image\Product;

/**
 * Product image
 */
abstract class Image extends \XLite\Model\Image\Product\Image implements \XLite\Base\IDecorator
{
	public function getRelativePath()
	{
		return  LC_IMAGES_URL . '/' . $this->getRepository()->getStorageName() . '/' . 
				rawurlencode($this->getPath());
	}
}
