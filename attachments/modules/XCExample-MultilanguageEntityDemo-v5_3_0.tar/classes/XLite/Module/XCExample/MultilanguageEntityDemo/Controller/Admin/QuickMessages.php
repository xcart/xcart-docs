<?php

namespace XLite\Module\XCExample\MultilanguageEntityDemo\Controller\Admin;

class QuickMessages extends \XLite\Controller\Admin\AAdmin
{
}