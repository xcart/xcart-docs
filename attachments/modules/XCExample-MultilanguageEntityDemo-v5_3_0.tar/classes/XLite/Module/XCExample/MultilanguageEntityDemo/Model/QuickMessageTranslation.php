<?php

namespace XLite\Module\XCExample\MultilanguageEntityDemo\Model;

/**
 * @Entity
 *
 * @Table (name="quick_message_translations")
 */

class QuickMessageTranslation extends \XLite\Model\Base\Translation
{
    /**
     *
     * @Column (type="text")
     */
    protected $body;

    public function getBody()
    {
        return $this->body;
    }

    public function setBody($value)
    {
        $this->body = $value;
        return $this;
    }    
}