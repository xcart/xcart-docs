<?php

namespace XLite\Module\XCExample\MultilanguageEntityDemo\Model\Repo;

class QuickMessage extends \XLite\Model\Repo\ARepo 
{
    protected $defaultOrderBy = 'id';
}