<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\MultilanguageEntityDemo\View\Page\Admin;

/**
 * Quick messages page view
 *
 * @ListChild (list="admin.center", zone="admin")
 */
class QuickMessages extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('quick_messages'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/XCExample/MultilanguageEntityDemo/page/quick_messages/body.twig';
    }
}