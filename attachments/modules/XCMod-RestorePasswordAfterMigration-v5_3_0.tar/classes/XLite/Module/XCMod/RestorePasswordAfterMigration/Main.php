<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCMod\RestorePasswordAfterMigration;

/**
 * Main module
 */
abstract class Main extends \XLite\Module\AModule
{
    /**
     * Author name
     *
     * @return string
     */
    public static function getAuthorName()
    {
        return 'X-Cart team';
    }

    /**
     * Module name
     *
     * @return string
     */
    public static function getModuleName()
    {
        return 'Small mod: user passwords after migration';
    }

    /**
     * Module description
     *
     * @return string
     */
    public static function getDescription()
    {
        return 'When you migrate to X-Cart, user passwords cannot be migrated due to security concerns. Suggest your existing customers to recover their passwords, when they log in.';
    }

    /**
     * Get module major version
     *
     * @return string
     */
    public static function getMajorVersion()
    {
        return '5.3';
    }

    /**
     * Module version
     *
     * @return string
     */
    public static function getMinorVersion()
    {
        return '0';
    }

    public static function showSettingsForm() 
    {
        return true;
    }    
}