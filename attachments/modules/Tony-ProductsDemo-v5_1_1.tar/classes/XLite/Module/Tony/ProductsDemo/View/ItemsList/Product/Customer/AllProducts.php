<?php 

namespace XLite\Module\Tony\ProductsDemo\View\ItemsList\Product\Customer; 

/** 
 * 
 * @ListChild (list="center.bottom", zone="customer", weight="300") 
 */ 

class AllProducts extends \XLite\View\ItemsList\Product\Customer\ACustomer
{ 
    public static function getAllowedTargets()  
    {  
        $return = array('all_products'); 

        return $return;  
    } 

    protected function getPagerClass()
    {
        return '\XLite\View\Pager\Infinity';
    }

    protected function getData(\XLite\Core\CommonCell $cnd, $countOnly = false)
    {
        return \XLite\Core\Database::getRepo('\XLite\Model\Product')->search(
            $cnd,
            $countOnly
        );
    }
}