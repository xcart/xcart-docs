<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCMod\SkuLength\Model;

/**
 * The "product" model class
 */
abstract class Product extends \XLite\Model\Product implements \XLite\Base\IDecorator
{
   /**
    * Product SKU
    *
    * @var string
    *
    * @Column (type="string", length=255, nullable=true)
    */
   protected $sku;    
}