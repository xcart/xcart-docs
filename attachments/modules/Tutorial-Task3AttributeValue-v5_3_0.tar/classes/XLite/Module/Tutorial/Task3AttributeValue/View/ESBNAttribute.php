<?php

namespace XLite\Module\Tutorial\Task3AttributeValue\View;

/**
 *
 * @ListChild (list="product.details.page.info", weight="20")
 *
 */

class ESBNAttribute extends \XLite\View\AView
{
    protected function getDefaultTemplate()
    {
        return 'modules/Tutorial/Task3AttributeValue/esbn-attribute.twig';
    }

    protected function getESBNValue()
    {
        foreach ($this->getProduct()->getAttributes() as $attribute) {

            if ($attribute->getName() == 'ESBN') {

                $value = $attribute->getAttributeValue($this->getProduct(), true);

                if (is_array($value)) {
                    $value = implode($attribute::DELIMITER, $value);
                }

                return $value;
            }
        }

        return null;
    }
}