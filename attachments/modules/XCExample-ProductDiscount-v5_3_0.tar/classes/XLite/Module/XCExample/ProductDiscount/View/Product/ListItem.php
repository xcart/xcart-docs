<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\ProductDiscount\View\Product;

/**
 * ACustomer
 */
abstract class ListItem extends \XLite\View\Product\ListItem implements \XLite\Base\IDecorator
{
    protected function getLabels()
    {
        $labels = parent::getLabels();
        $product = $this->getProduct();

        if ($product->isMyDiscount()) {
            $labels += array('my-discount' => static::t('10% off'));
        }

        return $labels;
    }
}