<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\HidingAttributes\View\Product\Details\Customer;

/**
 * Product attributes
 */
abstract class Attributes extends \XLite\View\Product\Details\Customer\Attributes implements \XLite\Base\IDecorator
{
    public function getAttrList()
    {
        $attributes = parent::getAttrList();
        $return = array();

        foreach ($attributes as $attr) {

            if (strtoupper($attr['name']) != 'HIDDEN-ATTRIBUTE') {
                $return[] = $attr;
            }
        }

        return $return;
    }
}
