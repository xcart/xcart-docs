<?php

namespace XLite\Module\XCExample\JsControllerDemo\View;

/**
 * @ListChild (list="sidebar.single", zone="customer", weight="500")
 * @ListChild (list="sidebar.first", zone="customer", weight="500")
 */

class SideBarBox extends \XLite\View\SideBarBox
{
    protected static $product = null;

    protected function getHead()
    {
        return 'Random Product';
    }

    protected function getDir()
    {
        return 'modules/XCExample/JsControllerDemo/sidebarbox';
    }

    public function getJSFiles()
    {
        $list = parent::getJSFiles();
        $list[] = 'modules/XCExample/JsControllerDemo/js/controller.js';

        return $list;
    }

    public function getCSSFiles()
    {
        $list = parent::getCSSFiles();
        $list[] = 'modules/XCExample/JsControllerDemo/css/style.css';

        return $list;
    }

    protected function getBlockClasses()
    {
        return parent::getBlockClasses() . ' block-random-product';
    }

    protected function getRandomProduct()
    {
        if (is_null(static::$product)) {
            static::$product = \XLite\Module\XCExample\JsControllerDemo\Controller\Customer\RandomProduct::fetchRandomProduct();
        }

        return static::$product;
    }
}