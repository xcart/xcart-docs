<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\JsControllerDemo\Controller\Customer;

/**
 * Abstract controller for Customer interface
 */
class RandomProduct extends \XLite\Controller\Customer\ACustomer
{
    public function doNoAction()
    {
        if ($this->isAJAX()) {
            $product = static::fetchRandomProduct();

            $return = array(
                'name'  => $product->getName(),
                'id'    => $product->getProductId(),
                'img'   => $product->getImage()->getFrontURL(),
            );

            $return = json_encode($return);

            header('Content-Type: application/json; charset=UTF-8');
            header('Content-Length: ' . strlen($return));
            header('ETag: ' . md5($return));

            print ($return);
        }

        die();
    }

    static function fetchRandomProduct()
    {
        $productIds = \XLite\Core\Database::getRepo('XLite\Model\Product')->createQueryBuilder('p')
            ->select('p.product_id AS id')
            ->getArrayResult();

        $index = rand(0, count($productIds) - 1);

        return \XLite\Core\Database::getRepo('XLite\Model\Product')->find($productIds[$index]['id']);
    }
}