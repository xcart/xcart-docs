/* vim: set ts=2 sw=2 sts=2 et: */

jQuery('#generate-random-product').click(function(){
  core.get(
    URLHandler.buildURL({
      target: 'random_product',
    })
  ).done(function (data) {
    jQuery('.block-random-product div.image img').attr('src', data.img);
    jQuery('.block-random-product div.link').html(
        '<a href="?target=product&product_id' + data.id + '">'
        + data.name + '</a>'
    );
  })
});