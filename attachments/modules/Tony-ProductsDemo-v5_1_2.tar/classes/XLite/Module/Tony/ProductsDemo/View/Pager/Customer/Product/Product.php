<?php

namespace XLite\Module\Tony\ProductsDemo\View\Pager\Customer\Product;

class Product extends \XLite\View\Pager\Customer\Product\AProduct
{
}