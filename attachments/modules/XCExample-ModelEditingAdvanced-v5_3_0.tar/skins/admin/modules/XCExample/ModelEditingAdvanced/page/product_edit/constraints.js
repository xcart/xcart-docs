/* vim: set ts=2 sw=2 sts=2 et: */

/**
 * Constraints
 *
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

define('modules/XCExample/ModelEditingAdvanced/page/product_edit/constraints', ['vue/vue'], function (Vue) {

  Vue.validator('XCExample_ModelEditingAdvanced_Even', function (value, rule) {
    return !!value && !(parseInt(value) % 2);
  });

});
