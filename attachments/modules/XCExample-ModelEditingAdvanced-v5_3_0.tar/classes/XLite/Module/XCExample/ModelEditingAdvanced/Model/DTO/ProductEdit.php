<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\ModelEditingAdvanced\Model\DTO;

use Symfony\Component\Validator\Context\ExecutionContextInterface;
use XLite\Core\Translation;
use XLite\Model\DTO\Base\CommonCell;

class ProductEdit extends \XLite\Model\DTO\Base\ADTO
{
    /**
     * @param ProductEdit               $dto
     * @param ExecutionContextInterface $context
     */
    public static function validate($dto, ExecutionContextInterface $context)
    {
        if ($dto->default->sku && !static::isSKUValid($dto)) {
            static::addViolation($context, 'default.sku', Translation::lbl('SKU must be unique'));
        }
    }

    /**
     * @param ProductEdit $dto
     *
     * @return boolean
     */
    protected static function isSKUValid($dto)
    {
        $sku = $dto->default->sku;
        $identity = $dto->default->identity;

        /** @var \XLite\Model\Product $entity */
        $entity = \XLite\Core\Database::getRepo('XLite\Model\Product')->findOneBySku($sku);

        return !$entity || (int) $entity->getProductId() === (int) $identity;
    }

    /**
     * @param mixed|\XLite\Model\Product $object
     */
    protected function init($object)
    {
        $this->default = new CommonCell([
            'identity' => $object->getProductId(),

            'generate_sku'     => !(boolean) $object->getProductId(),
            'sku'              => $object->getSku(),
            'name'             => $object->getName(),
            'price'            => $object->getPrice(),
            'full_description' => $object->getDescription(),
        ]);

        $this->price = new CommonCell([
            'price'              => $object->getPrice(),
            'inventory_tracking' => new CommonCell([
                'inventory_tracking' => $object->getInventoryEnabled(),
                'quantity'           => $object->getAmount(),
            ]),
        ]);
    }

    /**
     * @param \XLite\Model\Product $object
     * @param array|null           $rawData
     *
     * @return mixed
     */
    public function populateTo($object, $rawData = null)
    {
        $default = $this->default;
        $object->setSku(trim($default->sku));
        $object->setName((string) $default->name);
        $object->setDescription((string) $rawData['default']['full_description']);

        $price = $this->price;
        $object->setPrice($price->price);
        $object->setInventoryEnabled((boolean) $price->inventory_tracking->inventory_tracking);
        $object->setAmount($price->inventory_tracking->quantity);
    }

    /**
     * @param \XLite\Model\Product $object
     * @param array|null           $rawData
     *
     * @return mixed
     */
    public function afterCreate($object, $rawData = null)
    {
        \XLite\Core\Database::getRepo('XLite\Model\Attribute')->generateAttributeValues($object);

        if (!$object->getSku()) {
            $sku = \XLite\Core\Database::getRepo('XLite\Model\Product')->generateSKU($object);
            $object->setSku((string) $sku);
        }
    }

    /**
     * @param \XLite\Model\Product $object
     * @param array|null           $rawData
     *
     * @return mixed
     */
    public function afterUpdate($object, $rawData = null)
    {
        if ($this->default->generate_sku) {
            $sku = \XLite\Core\Database::getRepo('XLite\Model\Product')->generateSKU($object);
            $object->setSku((string) $sku);
        }
    }
}
