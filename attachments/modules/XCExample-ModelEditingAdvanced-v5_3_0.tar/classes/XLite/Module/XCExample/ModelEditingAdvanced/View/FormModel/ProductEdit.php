<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * Copyright (c) 2011-present Qualiteam software Ltd. All rights reserved.
 * See https://www.x-cart.com/license-agreement.html for license details.
 */

namespace XLite\Module\XCExample\ModelEditingAdvanced\View\FormModel;

class ProductEdit extends \XLite\View\FormModel\AFormModel
{
    /**
     * @return array
     */
    public function getJSFiles()
    {
        $list = parent::getJSFiles();
        $list[] = 'modules/XCExample/ModelEditingAdvanced/page/product_edit/constraints.js';

        return $list;
    }

    /**
     * Do not render form_start and form_end in null returned
     *
     * @return string|null
     */
    protected function getTarget()
    {
        return 'example_product_edit_advanced';
    }

    /**
     * @return string
     */
    protected function getAction()
    {
        return 'update';
    }

    /**
     * @return array
     */
    protected function getActionParams()
    {
        $identity = $this->getDataObject()->default->identity;

        return $identity ? ['product_id' => $identity] : [];
    }

    /**
     * @return array
     */
    protected function defineSections()
    {
        $list = parent::defineSections();
        $list['price'] = [
            'label'       => static::t('Price'),
            'help'        => static::t('In this section you can define product price.'),
            'description' => static::t('Sections for price.'),
            'collapse'    => true,
            'expanded'    => false,
            'position'    => 100,
        ];

        return $list;
    }

    /**
     * @return array
     */
    protected function defineFields()
    {
        $skuMaxLength = \XLite\Core\Database::getRepo('XLite\Model\Product')->getFieldInfo('sku', 'length');
        $nameMaxLength = \XLite\Core\Database::getRepo('XLite\Model\ProductTranslation')->getFieldInfo('name', 'length');

        $currency = \XLite::getInstance()->getCurrency();
        $currencySymbol = $currency->getCurrencySymbol(false);

        $schema = [
            self::SECTION_DEFAULT => [
                'generate_sku'     => [
                    'label'    => static::t('Generate SKU'),
                    'help'     => static::t('You can generate SKU'),
                    'type'     => 'XLite\View\FormModel\Type\SwitcherType',
                    'position' => 100,
                ],
                'sku'              => [
                    'label'       => static::t('SKU'),
                    'constraints' => [
                        'XLite\Core\Validator\Constraints\MaxLength' => [
                            'length'  => $skuMaxLength,
                            'message' =>
                                static::t('SKU length must be less then {{length}}', ['length' => $skuMaxLength]),
                        ],
                    ],
                    'enable_when' => [
                        'default' => [
                            'generate_sku' => '',
                        ],
                    ],
                    'position'    => 200,
                ],
                'name'             => [
                    'label'       => static::t('Product name'),
                    'description' => static::t('Product name'),
                    'required'    => true,
                    'constraints' => [
                        'Symfony\Component\Validator\Constraints\NotBlank' => [
                            'message' => static::t('This field is required'),
                        ],
                        'XLite\Core\Validator\Constraints\MaxLength'       => [
                            'length'  => $nameMaxLength,
                            'message' =>
                                static::t('Name length must be less then {{length}}', ['length' => $nameMaxLength]),
                        ],
                    ],
                    'position'    => 300,
                ],
                'full_description' => [
                    'label'    => static::t('Description'),
                    'type'     => 'XLite\View\FormModel\Type\TextareaAdvancedType',
                    'position' => 400,
                ],
            ],
            'price'               => [
                'price'              => [
                    'label'       => static::t('Price'),
                    'type'        => 'XLite\View\FormModel\Type\SymbolType',
                    'symbol'      => $currencySymbol,
                    'pattern'     => [
                        'alias'          => 'currency',
                        'prefix'         => '',
                        'rightAlign'     => false,
                        'groupSeparator' => $currency->getThousandDelimiter(),
                        'radixPoint'     => $currency->getDecimalDelimiter(),
                        'digits'         => $currency->getE(),
                    ],
                    'constraints' => [
                        'Symfony\Component\Validator\Constraints\GreaterThanOrEqual' => [
                            'value'   => 0,
                            'message' => static::t('Minimum value is X', ['value' => 0]),
                        ],
                    ],
                    'position'    => 100,
                ],
                'inventory_tracking' => [
                    'label'    => static::t('Inventory tracking is'),
                    'type'     => 'XLite\View\FormModel\Type\Base\CompositeType',
                    'fields'   => [
                        'inventory_tracking' => [
                            'type'     => 'XLite\View\FormModel\Type\SwitcherType',
                            'position' => 100,
                        ],
                        'quantity'           => [
                            'label'       => static::t('Quantity in stock'),
                            'type'        => 'XLite\View\FormModel\Type\PatternType',
                            'pattern'     => [
                                'alias'      => 'integer',
                                'rightAlign' => false,
                            ],
                            'constraints' => [
                                'XLite\Module\XCExample\ModelEditingAdvanced\Core\Validator\Constraints\Even' => [
                                    'message' => static::t('Only even value allowed'),
                                ],
                            ],
                            'show_when'   => [
                                'price' => [
                                    'inventory_tracking' => [
                                        'inventory_tracking' => '1',
                                    ],
                                ],
                            ],
                            'position'    => 200,
                        ],
                    ],
                    'position' => 200,
                ],
            ],
        ];

        return $schema;
    }
}
