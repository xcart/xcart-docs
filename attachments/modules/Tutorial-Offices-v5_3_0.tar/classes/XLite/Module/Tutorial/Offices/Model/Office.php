<?php

namespace XLite\Module\Tutorial\Offices\Model;

/**
 * Class Office
 * @Entity
 * @Table (name="offices")
 */

class Office extends \XLite\Model\AEntity
{
    /**
     * @Id
     * @GeneratedValue (strategy="AUTO")
     * @Column         (type="integer")
     */
    protected $id;

    /**
     * @Column (type="text")
     */
    protected $name;

    /**
     * @OneToOne (targetEntity="XLite\Module\Tutorial\Offices\Model\Image\Office", mappedBy="office", cascade={"all"})
     */
    protected $image;

    /**
     * @Column (type="text")
     */
    protected $address;

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * @param mixed $image
     */
    public function setImage($image)
    {
        $this->image = $image;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @param mixed $address
     */
    public function setAddress($address)
    {
        $this->address = $address;
    }
}
