<?php

namespace XLite\Module\Tutorial\Offices\Model\Repo;

class Office extends \XLite\Model\Repo\ARepo
{
}