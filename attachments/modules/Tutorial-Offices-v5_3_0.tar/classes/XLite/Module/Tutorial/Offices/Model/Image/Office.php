<?php

namespace XLite\Module\Tutorial\Offices\Model\Image;

/**
 * @Entity
 * @Table  (name="office_images")
 */

class Office extends \XLite\Model\Base\Image
{
    /**
     * @ManyToOne  (targetEntity="\XLite\Module\Tutorial\Offices\Model\Office", inversedBy="image")
     * @JoinColumn (name="officeId", referencedColumnName="id")
     */
    protected $office;

    /**
     * @Column (type="string", length=255)
     */
    protected $alt = '';
}