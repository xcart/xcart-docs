<?php

namespace XLite\Module\Tutorial\Offices\View\Form\Model;

class Office extends \XLite\View\Form\AForm
{
    protected function getDefaultTarget()
    {
        return 'create_office';
    }

    protected function getDefaultAction()
    {
        return 'update';
    }

    protected function getDefaultParams()
    {
        return array(
            'id' => \XLite\Core\Request::getInstance()->id,
        );
    }
}