<?php

namespace XLite\Module\Tutorial\Offices\View\Model;

class Office extends \XLite\View\Model\AModel
{
    protected $schemaDefault = [
        'name' => [
            self::SCHEMA_CLASS    => 'XLite\View\FormField\Input\Text',
            self::SCHEMA_LABEL    => 'Office\'s name',
            self::SCHEMA_REQUIRED => true,
        ],
        'image' => [
            self::SCHEMA_CLASS    => 'XLite\View\FormField\FileUploader\Image',
            self::SCHEMA_LABEL    => 'Office\'s name',
        ],
        'address' => [
            self::SCHEMA_CLASS    => 'XLite\View\FormField\Input\Text',
            self::SCHEMA_LABEL    => 'Office\'s full address',
            self::SCHEMA_REQUIRED => true,
        ],
    ];

    public function getModelId()
    {
        return \XLite\Core\Request::getInstance()->id;
    }

    protected function getDefaultModelObject()
    {
        $model = $this->getModelId()
            ? \XLite\Core\Database::getRepo('XLite\Module\Tutorial\Offices\Model\Office')->find($this->getModelId())
            : null;

        return $model ?: new \XLite\Module\Tutorial\Offices\Model\Office;
    }

    protected function getFormClass()
    {
        return '\XLite\Module\Tutorial\Offices\View\Form\Model\Office';
    }
}