<?php

namespace XLite\Module\Tutorial\Offices\View\ItemsList\Model;

class Offices extends \XLite\View\ItemsList\Model\Table
{
    protected function defineColumns()
    {
        return array(
            'name' => array(
                static::COLUMN_NAME     => static::t('Office\'s name'),
                static::COLUMN_ORDERBY  => 100,
                static::COLUMN_LINK      => 'create_office',
            ),

        );
    }

    protected function defineRepositoryName()
    {
        return 'XLite\Module\Tutorial\Offices\Model\Office';
    }

    protected function isRemoved()
    {
        return true;
    }

    protected function isCreation()
    {
        return static::CREATE_INLINE_TOP;
    }

    protected function getCreateURL()
    {
        return $this->buildURL('create_office');
    }

    protected function getCreateButtonLabel()
    {
        return 'Create office';
    }

    protected function wrapWithFormByDefault()
    {
        return true;
    }

    protected function getFormTarget()
    {
        return 'offices';
    }
}