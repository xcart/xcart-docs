<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tutorial\Offices\Model\Repo\Image;

class Office extends \XLite\Model\Repo\Base\Image
{
    /**
     * Returns the name of the directory within '<X-Cart>/images' where images are stored
     */
    public function getStorageName()
    {
        return 'office';
    }
}