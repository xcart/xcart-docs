<?php
namespace XLite\Module\XCartDevs\ChangeSearchDefaults\View\Form\Product\Search\Customer;
class SimpleForm extends \XLite\View\Form\Product\Search\Customer\SimpleForm implements \XLite\Base\IDecorator
{
   protected function getDefaultParams()
   {
       $params = parent::getDefaultParams();
       $params[\XLite\View\ItemsList\Product\Customer\Search::PARAM_INCLUDING] = \XLite\Model\Repo\Product::INCLUDING_ALL;
       return $params;
   }
}
?>
