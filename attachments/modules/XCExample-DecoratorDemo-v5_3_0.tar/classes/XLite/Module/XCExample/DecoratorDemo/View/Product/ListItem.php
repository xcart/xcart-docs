<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\DecoratorDemo\View\Product;

/**
 * Product list item widget
 */
abstract class ListItem extends \XLite\View\Product\ListItem implements \XLite\Base\IDecorator
{
    protected function isQuickLookEnabled()
    {
        return false;
    }    
}
