<?php

namespace XLite\Module\Tony\CMSLinksAdjustment\View\Menu\Customer;

class Footer extends \XLite\View\Menu\Customer\Footer implements \XLite\Base\IDecorator
{
    protected function getDefaultTemplate()
    {
        return 'modules/Tony/CMSLinksAdjustment/footer_menu.tpl';
    }
}