<?php

namespace XLite\Module\Tony\CMSLinksAdjustment\CDev\SimpleCMS\View\Menu\Customer;

/**
 * @LC_Dependencies ("CDev\SimpleCMS")
 */

class FooterMenu extends \XLite\View\Menu\Customer\Footer implements \XLite\Base\IDecorator
{
	protected function defineItems()
	{
		$menu = parent::defineItems();
		$return = array();

		$linksInSeparateWindows = array (
			'shipping',
			);

		foreach ($menu as $item) {

			if (in_array(strtolower($item['label']), $linksInSeparateWindows)) {
				$item['aboutBlank'] = true;
			}

			$return[] = $item;
		}

		return $return;
	}
}