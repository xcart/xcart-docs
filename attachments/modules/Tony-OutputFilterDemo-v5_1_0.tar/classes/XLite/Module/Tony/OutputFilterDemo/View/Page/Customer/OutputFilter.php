<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\OutputFilterDemo\View\Page\Customer;

/**
 * Output filter page view
 *
 * @ListChild (list="center")
 */
class OutputFilter extends \XLite\View\AView
{
    /**
     * Return list of allowed targets
     *
     * @return array
     */
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('output_filter'));
    }

    /**
     * Return widget default template
     *
     * @return string
     */
    protected function getDefaultTemplate()
    {
        return 'modules/Tony/OutputFilterDemo/page/output_filter/body.tpl';
    }
}