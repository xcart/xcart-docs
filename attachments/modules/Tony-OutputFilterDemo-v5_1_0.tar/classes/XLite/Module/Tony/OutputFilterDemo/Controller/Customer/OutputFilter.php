<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\OutputFilterDemo\Controller\Customer;

/**
 * Output filter controller
 */
class OutputFilter extends \XLite\Controller\Customer\ACustomer
{
}