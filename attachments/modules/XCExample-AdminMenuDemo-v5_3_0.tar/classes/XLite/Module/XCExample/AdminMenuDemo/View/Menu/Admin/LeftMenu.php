<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\XCExample\AdminMenuDemo\View\Menu\Admin;

/**
 * Left side menu widget
 */
abstract class LeftMenu extends \XLite\View\Menu\Admin\LeftMenu implements \XLite\Base\IDecorator
{
    protected function defineItems()
    {
        $items = parent::defineItems();

        // creating new item 
        // Catalog > Another link to products

        $items['catalog'][self::ITEM_CHILDREN]['extra_product_list'] = array(
            self::ITEM_TITLE  => static::t('Products (new link)'),
            self::ITEM_TARGET => 'product_list',
            self::ITEM_WEIGHT => 250,
        );

        $items['catalog'][self::ITEM_CHILDREN]['google'] = array (
            self::ITEM_TITLE    => 'Google menu item',
            self::ITEM_LINK     => 'https://google.com',
            self::ITEM_WEIGHT   => 500,
        );        

        // removing Catalog > Classes & attibutes item

        unset($items['catalog'][self::ITEM_CHILDREN]['product_classes']);

        // changing name of Catalog > Products item to 'New products title'

        $items['catalog'][self::ITEM_CHILDREN]['product_list'][static::ITEM_TITLE] = 'Products (title changed)';

        // adding new menu with the most sophisticated title 'New menu'

        $items['new_menu'] = [
            static::ITEM_TITLE    => static::t('New menu'),
            static::ITEM_ICON_SVG => 'images/fa-cog.svg',
            static::ITEM_WEIGHT   => 500,
            // static::ITEM_TARGET   => 'product_list',
            self::ITEM_CHILDREN => [
                'new_menu' => [
                    self::ITEM_TITLE    => 'Google menu item',
                    self::ITEM_LINK     => 'https://google.com',
                    self::ITEM_WEIGHT   => 500,
                ],
            ]
        ];

        return $items;
    }
}