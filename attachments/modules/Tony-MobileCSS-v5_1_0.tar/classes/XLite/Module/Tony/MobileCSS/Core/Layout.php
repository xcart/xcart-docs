<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\MobileCSS\Core;

class Layout extends \XLite\Core\Layout implements \XLite\Base\IDecorator
{
    public function registerResources(array $resources, $index, $interface = null)
    {
        parent::registerResources($resources, $index, $interface);

        if (\XLite\Core\Request::isMobileDevice()) {

            $files = array(
                'modules/Tony/MobileCSS/css/custom.css',
            );

            $this->registerResourcesByType($files, 100, $interface, \XLite\View\AView::RESOURCE_CSS);
        }
    }
}
