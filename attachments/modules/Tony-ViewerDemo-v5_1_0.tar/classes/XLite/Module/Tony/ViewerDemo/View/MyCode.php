<?php
namespace XLite\Module\Tony\ViewerDemo\View;
/**
 * @ListChild (list="order.operations", weight="150", zone="admin")
 */
class MyCode extends \XLite\View\AView
{
	protected function getDefaultTemplate()
	{
		return 'modules/Tony/ViewerDemo/mycode.tpl';
	}
	protected function getWeekDay()
	{
		return date('l');
	}
}