<?php
// vim: set ts=4 sw=4 sts=4 et:

namespace XLite\Module\Tony\PopupDemo\View\Button;

/**
 * Demo popup widget
 */
class DemoPopupButton extends \XLite\View\Button\APopupButton
{
    /**
     * getJSFiles
     *
     * @return array
     */
    public function getJSFiles()
    {
        $list = parent::getJSFiles();
        $list[] = 'modules/Tony/PopupDemo/page/tony_custom/popup_button.js';

        return $list;
    }

    /**
     * Return URL parameters to use in AJAX popup
     *
     * @return array
     */
    protected function prepareURLParams()
    {
        return array(
            'target'       => 'tony_custom',
            'widget'       => '\XLite\Module\Tony\PopupDemo\View\DemoWidget',
        );
    }

    /**
     * Return CSS classes
     *
     * @return string
     */
    protected function getClass()
    {
        return parent::getClass() . ' demo-popup';
    }

}
