<?php

namespace XLite\Module\Tony\PopupDemo\View;

/**
 * Demo loadable widget
 */

class DemoWidget extends \XLite\View\AView
{
    public static function getAllowedTargets()
    {
        return array_merge(parent::getAllowedTargets(), array('tony_custom'));
    }

    protected function getDefaultTemplate()
    {
        return 'modules/Tony/PopupDemo/page/tony_custom/demo_widget.tpl';
    }

    protected function getCartQuantity() {
        return \XLite\Model\Cart::getInstance()->countQuantity();
    }

    protected function getDisplaySubtotal() {
        return \XLite\Model\Cart::getInstance()->getDisplaySubtotal();
    }

    protected function getCurrency() {
        return \XLite\Model\Cart::getInstance()->getCurrency();
    }

    /**
     * Check if items are present
     *
     * @return boolean
     */
    protected function hasItems()
    {
        return (bool) \XLite\Model\Cart::getInstance()->countItems();
    }

    /**
     * Return up to 5 items from cart
     *
     * @return array
     */
    protected function getItemsList()
    {
        return array_slice(
            \XLite\Model\Cart::getInstance()->getItems()->toArray(),
            0,
            min(5, \XLite\Model\Cart::getInstance()->countItems())
        );
    }
}