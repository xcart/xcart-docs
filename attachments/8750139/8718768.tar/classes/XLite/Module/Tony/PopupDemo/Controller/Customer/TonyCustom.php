<?php

namespace XLite\Module\Tony\PopupDemo\Controller\Customer;

class TonyCustom extends \XLite\Controller\Customer\ACustomer
{	
}