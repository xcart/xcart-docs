<?php
// vim: set ts=4 sw=4 sts=4 et:

/**
 * X-Cart
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the software license agreement
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.x-cart.com/license-agreement.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to licensing@x-cart.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not modify this file if you wish to upgrade X-Cart to newer versions
 * in the future. If you wish to customize X-Cart for your needs please
 * refer to http://www.x-cart.com/ for more information.
 *
 * @category  X-Cart 5
 * @author    Qualiteam software Ltd <info@x-cart.com>
 * @copyright Copyright (c) 2011-2016 Qualiteam software Ltd <info@x-cart.com>. All rights reserved
 * @license   http://www.x-cart.com/license-agreement.html X-Cart 5 License Agreement
 * @link      http://www.x-cart.com/
 */

namespace XLite\Module\XCExample\ShippingDemo\Model\Shipping\Processor;


class MyProcessor extends \XLite\Model\Shipping\Processor\AProcessor
{
    /**
     * Returns processor Id
     *
     * @return string
     */
    public function getProcessorId()
    {
        return 'MyProcessor';
    }
    
    /**
     * Returns url for sign up
     *
     * @return string
     */
    public function getSettingsURL()
    {
        return \XLite\Module\XCExample\ShippingDemo\Main::getSettingsForm();
    }

    /**
     * Returns processor name
     *
     * @return string
     */
    public function getProcessorName()
    {
        return 'My Processor';
    }

    public function getRates($data, $ignoreCache)
    {
        $rates = array();

        $rate = new \XLite\Model\Shipping\Rate();
        $rate->setMethod($this->getShippingMethod());
        $rate->setBaseRate(10.00);

        $rates[] = $rate;

        return $rates;
    }

    protected function getShippingMethod()
    {
        return \XLite\Core\Database::getRepo('\XLite\Model\Shipping\Method')->findOneBy([
            'processor' => $this->getProcessorId(),
            'carrier'   => $this->getProcessorId()
        ]);
    }
}